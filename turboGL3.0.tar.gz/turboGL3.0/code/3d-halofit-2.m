(* ::Package:: *)

(* revised HaloFit from Takahashi et al. 2012 *)


(* auxiliary functions *)

ahf[n_,C_,z_]:=10^(+1.5222 +2.8553 n +2.3706 n^2 +0.9903 n^3 +0.2250 n^4 -0.6038 C +0.1749 OmegaQz[z](1+wave[z])); (* extra dependence *)
bhf[n_,C_,z_]:=10^(-0.5642 +0.5864 n +0.5716 n^2 -1.5474 C +0.2279 OmegaQz[z](1+wave[z])); (* extra dependence *)
chf[n_,C_]:=10^(+0.3698 +2.0404 n +0.8161 n^2 +0.5869 C);

gammahf[n_,C_]:=+0.1971 -0.0843 n +0.8460 C;
alphahf[n_,C_]:=Abs[+6.0835 +1.3373 n -0.1959 n^2 -5.5274 C]; (* extra dependence *)
betahf[n_,C_]:=+2.0379 -0.7354 n +0.3157 n^2 +1.2490 n^3 +0.3980 n^4 -0.1682 C; (* extra dependence *)
muhf[n_]:=0;
nuhf[n_]:=10^(+5.2105 +3.6902 n);

f1ahf[OM0_]:=OM0^-0.0732;
f2ahf[OM0_]:=OM0^-0.1423;
f3ahf[OM0_]:=OM0^0.0725;

f1bhf[OM0_]:=OM0^-0.0307;
f2bhf[OM0_]:=OM0^-0.0585;
f3bhf[OM0_]:=OM0^0.0743;

f1hf[OM0_,OK0_]:=OK0 (f1ahf[OM0]-f1bhf[OM0])/(1-OM0-0) + f1bhf[OM0];
f2hf[OM0_,OK0_]:=OK0 (f2ahf[OM0]-f2bhf[OM0])/(1-OM0-0) + f2bhf[OM0];
f3hf[OM0_,OK0_]:=OK0 (f3ahf[OM0]-f3bhf[OM0])/(1-OM0-0) + f3bhf[OM0];

fhf[y_]:=y/4 +y^2/8;


(* mass variance with gaussian filter *)

DEL2G0r[r_?NumericQ]:=NIntegrate[DEL2k0[a0 kp]/kp wgau[kp a0 r]^2,{kp,0,Infinity},Method->{Automatic,"SymbolicProcessing"->0},MaxRecursion->20,AccuracyGoal->3];
DEL2Gr[r_,z_]:=(*DEL2Gr[r,z]=*)DDz[z]^2 DEL2G0r[r];


(* nonlinear scale, effective index and spectral curvature *)

rsiz[z_]:=rsi/.FindRoot[DEL2Gr[rsi,z]^0.5==1,{rsi,2},AccuracyGoal->5];
ksiz[z_]:=1/rsiz[z];

(* eq. (59) *)
neff[z_,ksi_]:=(*neff[z,ksi]=*)-3+2 DDz[z]^2 NIntegrate[DEL2k0[a0 kp]/kp wgau[kp a0 /ksi]^2 (kp a0 /ksi)^2,{kp,0,Infinity},Method->{Automatic,"SymbolicProcessing"->0},MaxRecursion->20,AccuracyGoal->3];

(* eq. (60) *)
ceff[z_,ksi_]:=(*ceff[z,ksi]=*)(3+neff[z,ksi])^2 +4 DDz[z]^2 NIntegrate[DEL2k0[a0 kp]/kp wgau[kp a0 /ksi]^2 ((kp a0 /ksi)^2-(kp a0 /ksi)^4),{kp,0,Infinity},Method->{Automatic,"SymbolicProcessing"->0},MaxRecursion->20,AccuracyGoal->3];


(* the halo term *)

DEL2Hb[k_,z_,OM0_,OK0_,ksi_]:=ahf[neff[z,ksi],ceff[z,ksi],z] (k/ksi)^(3 f1hf[OM0,OK0])/(1+ bhf[neff[z,ksi],ceff[z,ksi],z](k/ksi)^f2hf[OM0,OK0]+(chf[neff[z,ksi],ceff[z,ksi]] f3hf[OM0,OK0] k/ksi)^(3-gammahf[neff[z,ksi],ceff[z,ksi]]));
DEL2Ha[k_,z_,ksi_]:=DEL2Hb[k,z,OmegaM0,OmegaK0,ksi]/(1+muhf[neff[z,ksi]] ksi/k +nuhf[neff[z,ksi]] (ksi/k)^2);


(* the quasi-linear term *)

DEL2Q[k_,z_,ksi_]:=DEL2k[k,z] ((1+DEL2k[k,z])^betahf[neff[z,ksi],ceff[z,ksi]] /(1+ alphahf[neff[z,ksi],ceff[z,ksi]] DEL2k[k,z])) Exp[-fhf[k/ksi]];


DEL2HaloFit[k_,z_,ksi_]:=DEL2Q[k,z,ksi]+DEL2Ha[k,z,ksi];
PkHaloFit[k_,z_,ksi_]:=DEL2HaloFit[k,z,ksi] 2\[Pi]^2/k^3;


(* This code is released under the GPL license. Copyright 2009-2014 by Valerio Marra (valerio.marra@me.com) *)
