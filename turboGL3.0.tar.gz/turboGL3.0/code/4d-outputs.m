(* ::Package:: *)

(* colors *)

hcolor=Join[{Orange,Green,Blue},Take[ColorData[2,"ColorList"],{1,-1,2}],Take[ColorData[5,"ColorList"],{1,-1,2}],Take[ColorData[7,"ColorList"],{1,-1,2}],Take[ColorData[10,"ColorList"],{1,-1,2}]];
hcolor=Join[hcolor,hcolor,hcolor,hcolor,hcolor,hcolor];


(* plot ranges *)

maxh=Max[tapx[[All,1]]];diffmax=diffi[[Position[tapx,{x_,y_}/;x==maxh][[1,1]]]];
minh=Min[tapx[[All,1]]];diffmin=diffi[[Position[tapx,{x_,y_}/;x==minh][[1,1]]]];

Which[
	Abs[maxh]<Abs[minh],sug=+1;liplot=maxh+diffmax/2;rancho={If[sigmaconvo==0,{- 3 liplot,liplot 1.1},{Min[{-2 sigmah[jz],- 3 liplot}],2 sigmah[jz]}],All};{ranchox1,ranchox2}=If[sigmaconvo==0,{- 2 liplot,liplot},{-2 sigmah[jz],2 sigmah[jz]}];
,
	Abs[maxh]>Abs[minh],sug=-1;liplot=minh-diffmin/2;rancho={If[sigmaconvo==0,{liplot 1.1,- 3 liplot},{-2 sigmah[jz],Max[{2 sigmah[jz],- 3 liplot}]}],All};{ranchox1,ranchox2}=If[sigmaconvo==0,{liplot,- 2 liplot},{-2 sigmah[jz],2 sigmah[jz]}];
];


(* plots *)

ag0=Table[{{tapx[[k,1]]+sug diffi[[k]]/2 ,tapx[[k,2]]},{tapx[[k,1]]-sug diffi[[k]]/2 ,tapx[[k,2]]}},{k,1,imax}];
taP=Flatten[ag0,1];
hplot[jz]=ListPlot[taP,Joined->True,Frame->True,PlotStyle->If[jz>0,hcolor[[jz]],Orange],ImageSize->600,AxesOrigin->{0,0},Axes->False,FrameStyle->20,
FrameLabel->{lbl,"PDF"},Filling->Axis,FillingStyle->Opacity[0.2,If[jz>0,hcolor[[jz]],Orange]],PlotRange->rancho];

swq0=Plot[pdfx[x],{x,ranchox1,ranchox2},PlotStyle->{Black}];
swq3=Show[{hplot[jz],swq0},ImageSize->600,Frame->True,Axes->False,GridLines->{{{demu[jz]+up[jz],{Green,Dashed}},{demu[jz]-down[jz],{Green,Dashed}},{0,{Gray,Thin}}},None},
FrameLabel->{lbl,"PDF"},FrameStyle->20,PlotRange->rancho];

If[
confinement==0
,
xhp=Null;
,
xh1=Histogram[XfT-1,Automatic,"PDF",ChartStyle->Directive[LightGray,EdgeForm[None]]];
xh2=SmoothHistogram[XfT-1,Automatic,PlotStyle->Black];
xhp=Show[xh1,xh2,Frame->True,FrameLabel->{"X-1",None,"LSS PDF"},FrameStyle->13,AxesOrigin->{0,0},ImageSize->300];
];


(* table *)

datat=Round[{EmptyB[zod],PFillB[zod],tmeanh[jz],demu[jz],dup[jz],sigmah[jz],sigmah[jz] Sqrt[NOz],tmeanh[jz]/sigmah[jz]},0.0001];AppendTo[datat,nneat[persca]];
sumat=TableForm[datat,TableHeadings->{{"Empty beam","Max demag","Mean","Mode","FWHM/2.35","\[Sigma]","\!\(\*SubscriptBox[\(\[Sigma]\), \(1, eff\)]\)","mean/\[Sigma]","purged"}},TableSpacing->2,TableAlignments->Center];


(* outputs *)

Print[Row[{"Grand total time used=",Round[gtt1+gtt2+gtt3+gtt4,.1],"s            -            nb total time used=",Round[SessionTime[]-tnb,.1],"s"}]];
Print[fiplot=Row[{swq3,"      ",Column[{sumat,"",xhp},Center]}]];


(* This code is released under the GPL license. Copyright 2009-2014 by Valerio Marra (valerio.marra@me.com) *)
