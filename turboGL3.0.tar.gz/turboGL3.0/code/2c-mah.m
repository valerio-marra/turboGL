(* ::Package:: *)

(* MAH - mass accretion history from Zhao et at 2009 *)


(* auxiliary functions *)

sM[M_]:=iDEL0M[M]10^(-M dlnDELM[M]);
wcon[z_,M_]:=delc[z]/sM[M];
pconc[z_,zb_,Mb_]:=1/(1+(wcon[zb,Mb]/4)^6) wcon[zb,Mb]/2 Max[{0,1-(Log[10,delc[z]]-Log[10,delc[zb]])/(0.272/wcon[zb,Mb])}];

dlogsdlogdc[z_,M_,zb_,Mb_]:=(wcon[z,M]-pconc[z,zb,Mb])/5.85;
Faux[z_,M_,zb_,Mb_]:=dlogsdlogdc[z,M,zb,Mb] iDEL0M[M]/delc[z] delc'[z]/iDEL0M'[M];

zfit004[x_,y_]=13 -0.734 x+0.907 y;(* useful to speed up the NDSolve *)
accuMAH=5;


(*MAHx[z_,MH_,zH_]:=Module[{output,mnds},
	If[MH==MHtest&&zH==zHtest,Null,mnds=NDSolve[{Mf'[zd]==Faux[zd,Mf[zd],zH,MH],Mf[zH]==MH},Mf,{zd,zH,20}];Mz[zd_]:=(Mf/.mnds[[1]])[zd];];
	output=Mz[z];
	MHtest=MH;zHtest=zH;(* not to repeat the NDSolve *)
	output
];

nAHx[z_,nH_,zH_]:=nM[MAHx[z,Mn[nH],zH]];*)


MAH[z_,MH_,zH_]:=(*MAH[z,MH,zH]=*)Module[{output,mnds},
	zmax=3zfit004[nM[MH],zH];If[zini<zmax,Print["Increase max redshift of growth function"]];
	mnds=NDSolve[{Mf'[zd]==Faux[zd,Mf[zd],zH,MH],Mf[zH]==MH},Mf,{zd,zH,zmax}];
	Mz[zd_]:=(Mf/.mnds[[1]])[zd];
	output=Mz[z];
	output
];

nAH[z_,nH_,zH_]:=nM[MAH[z,Mn[nH],zH]];


zM004[MH_,zH_]:=(*zM004[MH,zH]=*)Module[{output,mnds,Mz},
	zmax=3zfit004[nM[MH],zH];If[zini<zmax,Print["Increase max redshift of growth function"]];
	mnds=NDSolve[{Mf'[zd]==Faux[zd,Mf[zd],zH,MH],Mf[zH]==MH},Mf,{zd,zH,zmax}];
	Mz[zd_]:=(Mf/.mnds[[1]])[zd];
	output=zd/.FindRoot[Mz[zd]/MH==0.04,{zd,zH+1,zH,zmax},AccuracyGoal->accuMAH];
	output
];

zn004[nH_,zH_]:=zM004[Mn[nH],zH];


tM004[MH_,zH_]:=(*tM004[MH,zH]=*)Module[{output,mnds,Mz},
	zmax=3zfit004[nM[MH],zH];If[zini<zmax,Print["Increase max redshift of growth function"]];
	tmax=tz[zmax];tH=tz[zH];
	mnds=NDSolve[{Mf'[zd]==Faux[zd,Mf[zd],zH,MH],Mf[zH]==MH},Mf,{zd,zH,zmax}];
	Mz[zd_]:=(Mf/.mnds[[1]])[zd];
	output=td/.FindRoot[Mz[zt[td]]/MH==0.04,{td,tmax 1.2,tmax,tH},AccuracyGoal->accuMAH];
	output
];

tn004[nH_,zH_]:=tM004[Mn[nH],zH];


(* c wrt \[CapitalDelta]vir *)

cM004v[MH_,zH_]:=(*cM004v[MH,zH]=*)Module[{output,tdd,mnds,Mz},
	zmax=3zfit004[nM[MH],zH];If[zini<zmax,Print["Increase max redshift of growth function"]];
	tmax=tz[zmax];tH=tz[zH];
	mnds=NDSolve[{Mf'[zd]==Faux[zd,Mf[zd],zH,MH],Mf[zH]==MH},Mf,{zd,zH,zmax}];
	Mz[zd_]:=(Mf/.mnds[[1]])[zd];
	tdd=td/.FindRoot[Mz[zt[td]]/MH==0.04,{td,tmax 1.2,tmax,tH},AccuracyGoal->accuMAH];
	output=(4^8+(tH/tdd)^8.4)^(1/8);
	output
];

cn004v[nH_,zH_]:=cM004v[Mn[nH],zH];


(* c wrt \[CapitalDelta]mean *)

cM004m[MH_,zH_]:=(*cM004m[MH,zH]=*)Module[{output,tdd,mnds,Mz,cv},
	zmax=4zfit004[nM[MH],zH];If[zini<zmax,Print["Increase max redshift of growth function"]];
	tmax=tz[zmax];tH=tz[zH];
	mnds=NDSolve[{Mf'[zd]==Faux[zd,Mf[zd],zH,MH],Mf[zH]==MH},Mf,{zd,zH,zmax}];
	Mz[zd_]:=(Mf/.mnds[[1]])[zd];
	tdd=td/.FindRoot[Mz[zt[td]]/MH==0.04,{td,tmax 1.2,tmax,tH},AccuracyGoal->accuMAH];
	cv=(4^8+(tH/tdd)^8.4)^(1/8);
	output=cd/.FindRoot[norNFW[cv]DELTAvir[zH]/3==norNFW[cd]DeltaH/3,{cd,10},AccuracyGoal->accuMAH];
	output
];
cboost=1.;
cn004m[nH_,zH_]:=cboost cM004m[Mn[nH],zH];
chalo[M_,z_]:= cM004m[M,z];


(*(* 200m *)
Av=10.14 ;
Bv=-0.081;
Cv=-1.01;
Mpiv=2 10^12 /hh;
chalom[M_,z_]= Av (M/Mpiv)^Bv (1+z)^Cv;
cn004m[nH_,zH_]:=chalom[Mn[nH],zH];*)


(* This code is released under the GPL license. Copyright 2009-2014 by Valerio Marra (valerio.marra@me.com) *)
