(* ::Package:: *)

(* HaloFit from Smith et al. 2003 *)


(* auxiliary functions *)

ahf[n_,C_]:=10^(+1.4861 +1.8369 n +1.6762 n^2 +0.7940 n^3 +0.1670 n^4 -0.6206 C);
bhf[n_,C_]:=10^(+0.9463 +0.9466 n +0.3084 n^2 -0.9400 C);
chf[n_,C_]:=10^(-0.2807 +0.6669 n +0.3214 n^2 -0.0793 C);

gammahf[n_,C_]:=+0.8649 +0.2989 n +0.1631 C;
alphahf[n_]:=+1.3884 +0.3700 n -0.1452 n^2;
betahf[n_]:=+0.8291 +0.9854 n +0.3401 n^2;
muhf[n_]:=10^(-3.5442 +0.1908 n);
nuhf[n_]:=10^(+0.9589 +1.2857 n);

f1ahf[OM0_]:=OM0^-0.0732;
f2ahf[OM0_]:=OM0^-0.1423;
f3ahf[OM0_]:=OM0^0.0725;

f1bhf[OM0_]:=OM0^-0.0307;
f2bhf[OM0_]:=OM0^-0.0585;
f3bhf[OM0_]:=OM0^0.0743;

f1hf[OM0_,OK0_]:=OK0 (f1ahf[OM0]-f1bhf[OM0])/(1-OM0-0) + f1bhf[OM0];
f2hf[OM0_,OK0_]:=OK0 (f2ahf[OM0]-f2bhf[OM0])/(1-OM0-0) + f2bhf[OM0];
f3hf[OM0_,OK0_]:=OK0 (f3ahf[OM0]-f3bhf[OM0])/(1-OM0-0) + f3bhf[OM0];

fhf[y_]:=y/4 +y^2/8;


(* mass variance with gaussian filter *)

DEL2G0r[r_?NumericQ]:=NIntegrate[DEL2k0[a0 kp]/kp wgau[kp a0 r]^2,{kp,0,Infinity},Method->{Automatic,"SymbolicProcessing"->0},MaxRecursion->20,AccuracyGoal->3];
DEL2Gr[r_,z_]:=(*DEL2Gr[r,z]=*)DDz[z]^2 DEL2G0r[r];


(* nonlinear scale, effective index and spectral curvature *)

rsiz[z_]:=rsi/.FindRoot[DEL2Gr[rsi,z]^0.5==1,{rsi,2},AccuracyGoal->5];
ksiz[z_]:=1/rsiz[z];

(* eq. (59) *)
neff[z_,ksi_]:=(*neff[z,ksi]=*)-3+2 DDz[z]^2 NIntegrate[DEL2k0[a0 kp]/kp wgau[kp a0 /ksi]^2 (kp a0 /ksi)^2,{kp,0,Infinity},Method->{Automatic,"SymbolicProcessing"->0},MaxRecursion->20,AccuracyGoal->3];

(* eq. (60) *)
ceff[z_,ksi_]:=(*ceff[z,ksi]=*)(3+neff[z,ksi])^2 +4 DDz[z]^2 NIntegrate[DEL2k0[a0 kp]/kp wgau[kp a0 /ksi]^2 ((kp a0 /ksi)^2-(kp a0 /ksi)^4),{kp,0,Infinity},Method->{Automatic,"SymbolicProcessing"->0},MaxRecursion->20,AccuracyGoal->3];


(* the halo term *)

DEL2Hb[k_,z_,OM0_,OK0_,ksi_]:=ahf[neff[z,ksi],ceff[z,ksi]] (k/ksi)^(3 f1hf[OM0,OK0])/(1+ bhf[neff[z,ksi],ceff[z,ksi]](k/ksi)^f2hf[OM0,OK0]+(chf[neff[z,ksi],ceff[z,ksi]] f3hf[OM0,OK0] k/ksi)^(3-gammahf[neff[z,ksi],ceff[z,ksi]]));
DEL2Ha[k_,z_,ksi_]:=DEL2Hb[k,z,OmegaM0,OmegaK0,ksi]/(1+muhf[neff[z,ksi]] ksi/k +nuhf[neff[z,ksi]] (ksi/k)^2);


(* the quasi-linear term *)

DEL2Q[k_,z_,ksi_]:=DEL2k[k,z] ((1+DEL2k[k,z])^betahf[neff[z,ksi]] /(1+ alphahf[neff[z,ksi]] DEL2k[k,z])) Exp[-fhf[k/ksi]];


DEL2HaloFit[k_,z_,ksi_]:=DEL2Q[k,z,ksi]+DEL2Ha[k,z,ksi];
PkHaloFit[k_,z_,ksi_]:=DEL2HaloFit[k,z,ksi] 2\[Pi]^2/k^3;


(* This code is released under the GPL license. Copyright 2009-2014 by Valerio Marra (valerio.marra@me.com) *)
