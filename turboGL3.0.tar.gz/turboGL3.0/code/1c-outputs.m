(* ::Package:: *)

(*Row[{"Curvature radius: dR=",Round[1/Sqrt[Abs[RR[t0]]]]," Mpc   -   Spatial curvature radius: dK=",Round[Lk0]," Mpc"}];*)


(* outputs *)

pq1=Plot[{OmegaMz[z],OmegaQz[z],OmegaKz[z]},{z,0,3},PlotStyle->{Red,Green,Blue},Axes->False,Frame->True,PlotPoints->pp,MaxRecursion->rr,FrameStyle->fst,PlotRange->All,
FrameLabel->{"z",None,"\!\(\*SubscriptBox[\"\[CapitalOmega]\", \"M\"]\)(z) (red), \!\(\*SubscriptBox[\"\[CapitalOmega]\", \"Q\"]\)(z) (green) and \!\(\*SubscriptBox[\"\[CapitalOmega]\", \"K\"]\)(z) (blue)"}];
pq2=Plot[{dm[z],dmEdS[z]},{z,0,1.5},PlotStyle->{Green,Red},AxesOrigin->{0,0},Frame->True,PlotPoints->pp,MaxRecursion->rr,FrameStyle->fst,PlotRange->Automatic,
FrameLabel->{"z","\[CapitalDelta]m","Luminosity distance - EdS (red) and chosen model (green)"}];
pq3=GraphicsRow[{pq1,pq2},Spacings->Scaled[-0.05],ImageSize->920];

Print[Column[{
Row[{"Available cores: ",$ProcessorCount,"      Active parallel subkernels: ",$KernelCount}],
"",
Row[{"Age of the universe: \!\(\*SubscriptBox[\"t\", \"0\"]\)=",NumberForm[t0,3]," Gyr   -   ",
"sgn(k)=",Piecewise[{{"0",OmegaK0==0},{"-1",OmegaK0>0},{"+1",OmegaK0<-0}}],
"   -   \!\(\*SubscriptBox[\(z\), \(max\)]\)=",Round[zfar],
"            -            time used=",Round[dtt,.01],"s"}],
"",
pq3
}]];


(* This code is released under the GPL license. Copyright 2009-2014 by Valerio Marra (valerio.marra@me.com) *)
