(* ::Package:: *)

tt=SessionTime[];


(* to export the histogram *)

HPDF[jz]=tapx;
If[export==1,Export[ToFileName["results","hpdf_"<>ToString[jz]<>".dat"],HPDF[jz]],Null];


(* fit & analysis *)

tmeanh[jz]=Total[diffi tapx[[All,2]] tapx[[All,1]]];
sigmah[jz]=Total[diffi tapx[[All,2]] (tapx[[All,1]]-tmeanh[jz])^2]^(1/2);
skewnh[jz]=Total[diffi tapx[[All,2]] (tapx[[All,1]]-tmeanh[jz])^3]^(1/3);
kurtoh[jz]=Total[diffi tapx[[All,2]] (tapx[[All,1]]-tmeanh[jz])^4]^(1/4);

{demu2,normo9}=Sort[tapx,#1[[2]]>#2[[2]]&][[1]];

ClearAll[pdfx,pdfy];
If[
	sigmaconvo==0
,
	(*pdfx=Interpolation[tapx, Method->"Spline"];*)
	pdfy=SmoothKernelDistribution[kappaSIMc,MaxExtraBandwidths->0];
	pdfx[x_]:=PDF[pdfy,x];
,
	pdfx[dem_]:= Total[diffi tapx[[All,2]]Exp[-(dem-tapx[[All,1]])^2/(2 sigmaconvo^2)]/(Sqrt[2 \[Pi]] sigmaconvo)];
	sigmah[jz]=Sqrt[sigmah[jz]^2+sigmaconvo^2];
];

accuana=5;
Off[FindMaximum::lstol];
demu[jz]=x/.Last[FindMaximum[pdfx[x],{x,demu2,demu2-sigmah[jz]/2,demu2+sigmah[jz]/2},AccuracyGoal->accuana]];
On[FindMaximum::lstol];

downfwhm=x/.FindRoot[pdfx[x]==pdfx[demu[jz]]/2,{x,demu[jz]-sigmah[jz]/4,demu[jz]-2 sigmah[jz],demu[jz]},AccuracyGoal->accuana];
down[jz]=(demu[jz]-downfwhm)/Sqrt[2 Log[2]];
upfwhm=x/.FindRoot[pdfx[x]==pdfx[demu[jz]]/2,{x,demu[jz]+sigmah[jz]/4,demu[jz],demu[jz]+2 sigmah[jz]},AccuracyGoal->accuana];
up[jz]=(upfwhm-demu[jz])/Sqrt[2 Log[2]];
dup[jz]=(up[jz]+down[jz])/2;


dtt3=SessionTime[]-tt;
gtt4=dtt+dtt2+dtt3;


(* This code is released under the GPL license. Copyright 2009-2014 by Valerio Marra (valerio.marra@me.com) *)
