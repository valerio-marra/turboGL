(* ::Package:: *)

tt=SessionTime[];


(* to build the objs table, purging the irrelevant entries *)

auxto={};i=1;
While[
	Length[obj[i]]==8||Length[obj[i]]==7
,
	If[
		obj[i][[1]]!=0
	,
		If[Length[obj[i]]==7,AppendTo[obj[i],0],Null];
		AppendTo[auxto,i];
	,
		Null
	];
	i+=1;
];

objs=Table[obj[i],{i,auxto}];
Nobj=Length[objs];
objs[[All,{3,5}]]=objs[[All,{3,5}]]/hh;objs=Chop[objs,chip]; (* right units for RP and LP *)


objsS={};objsC={};
Do[If[objs[[io,5]]==0,AppendTo[objsS,objs[[io]]],AppendTo[objsC,objs[[io]]]];,{io,1,Nobj}];
NobjS=Length[objsS];
NobjC=Length[objsC];

betaS=objsS[[All,1]];
betaTOTS=Total[betaS];

betaC=objsC[[All,1]];
betaTOTC=Total[betaC];


(* to calculate the L&U mass fractions *)

beta=objs[[All,1]];
betaTOT=Total[beta];
If[betaTOT==0,confinement=0,Null];

DfL0=beta DfLU0; (* present-day \[CapitalDelta]f_L for the various objs *)
DfU0=(1-betaTOT)DfLU0; (* present-day \[CapitalDelta]f_U *)


cro=1;zp=1.5; (* the comoving filament volume fraction qf is calculated at z=0 and z=zp *)

results=
Table[
	Which[
		objs[[i,5]]==0 (* spherical obj *)
	,
		Vfp0=4 \[Pi]/3 objs[[i,3]]^3;
		Vf0=Vfp0/a0^3;
		RCC=objs[[i,4]];LCC=objs[[i,6]];
		Vfz=Vf0 (Boole[RCC==1] + Boole[RCC==0](1+zp)^3);
	,
		objs[[i,5]]!=0 (* cylindrical obj *)
	,
		Vfp0=\[Pi] objs[[i,3]]^2 objs[[i,5]];
		Vf0=Vfp0/a0^3;
		RCC=objs[[i,4]];LCC=objs[[i,6]];
		Vfz=Vf0 (Boole[RCC==1&&LCC==1] + Boole[RCC==1&&LCC==0](1+zp) + Boole[RCC==0&&LCC==1](1+zp)^2 + Boole[RCC==0&&LCC==0](1+zp)^3);
	];

	deltasLOC=Mn[objs[[i,2]]]/(Vfp0 rhoMz[0]);
	DnL0LOC=DfL0[[i]] rhoMC/Mn[objs[[i,2]]];
	deltaDressLOC=(deltasLOC(1+ DfHC0/DfL0[[i]]) +DfHNC0 +DfU0);
	MDL0LOC=Vfp0 rhoMz[0] deltaDressLOC;
	
	Which[
		cro==1(*&&confinement==1*)
	,
		qfb0LOC=Vf0 DnL0LOC;
		qfbzLOC=Vfz DnL0LOC;
	,
		cro==0(*&&confinement==1*)
	,
		qfb0LOC=1-Exp[-Vf0 DnL0LOC];
		qfbzLOC=1-Exp[-Vfz DnL0LOC];
	];

	{deltasLOC,DnL0LOC,MDL0LOC,qfb0LOC,qfbzLOC,deltaDressLOC} (* results *)
,
	{i,1,Nobj}
];

deltas=results[[All,1]];
DnL0=results[[All,2]];
MDL0=results[[All,3]];
qfb0=results[[All,4]];
qfbz=results[[All,5]];
deltaDress=results[[All,6]];


dtt3=SessionTime[]-tt;
gtt2=dtt+dtt2+dtt3;


(* This code is released under the GPL license. Copyright 2009-2014 by Valerio Marra (valerio.marra@me.com) *)
