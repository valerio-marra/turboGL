(* ::Package:: *)

Needs["Units`"];
Off[General::obspkg];
Needs["PhysicalConstants`"];
On[General::obspkg];


(*
Convert[Parsec,Meter] (* gives 30.857 10^15 m which is the SI definition *)
Convert[SolarMass,Gram] (* gives 1.9891 10^33 *)
GravitationalConstant
SpeedOfLight
*)


(* I will use Mpc, Gyr and M_sol *)

JulianYear= 31557600 Second;

cc=Convert[1. SpeedOfLight /((Mega Parsec) (Giga JulianYear)^-1),1]; (* Mpc/Gyr *)

HH=Convert[100. (Kilo Meter Second^-1) (Mega Parsec)^-1 /(Giga JulianYear)^-1,1]; (* Gyr^-1 *)
H0=hh HH;

GG=Convert[1. GravitationalConstant /((Mega Parsec)^3 SolarMass^-1 (Giga JulianYear)^-2),1]; (* Mpc^3 M_sol^-1 Gyr^-2 *)


(* cosmological quantities *)

a0=1; (* scale factor today (adimensional) *)

Lh0=cc/H0; (* Hubble radius today in Mpc *)
kh0=a0/Lh0; (* Hubble wavelength *)

rhoc0=3 H0^2/(8 \[Pi] GG); (* critical density today *)


(* This code is released under the GPL license. Copyright 2009-2014 by Valerio Marra (valerio.marra@me.com) *)
