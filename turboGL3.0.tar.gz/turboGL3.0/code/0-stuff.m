(* ::Package:: *)

(* parallel computation *)

paraker=0; (* 1 to parallelize vTable2, 0 otherwise *)

Off[LaunchKernels::nodef];

Which[paracomp==0,Null,paracomp==1,LaunchKernels[],paracomp>1,LaunchKernels[paracomp]];
vTable=If[paracomp>0,ParallelTable,Table];

Which[paraker==0,Null,paraker==1,LaunchKernels[],paraker>1,LaunchKernels[paraker]];
vTable2=If[paraker>0,ParallelTable,Table];

On[LaunchKernels::nodef];

$HistoryLength=0;
If[paraker==1,ParallelEvaluate[$HistoryLength=0;]];


(* radiation density parameter *)

OmegaRad[hh_]:=2.469 10^-5/hh^2 (1+0.2271 3.046);
OmegaL0fun[hh_,om_]:=1-om-OmegaRad[hh];
auxf1[iset_]:=AppendTo[parSet[iset],OmegaL0fun[parSet[iset][[1]],parSet[iset][[2]]]];


(* stuff *)

ACCU=1000; (* normal is 1000, 5000 for extra accuracy - for MaxStepFraction option in NDSolve *)
pp=8;rr=3;fst=16; (* plotting options *)
chip=10^-20;

nneat[x_]:=NumberForm[x,2,ExponentFunction->(If[-2<#<2,Null,#]&)]; (* neat numbers *)

RandomInteger[PoissonDistribution[.001]]; (* to cache it *)


nonconstantB[x_]:=(
dbinsB={x[[1]]}; (* first bin *)
Do[
	AppendTo[dbinsB,(x[[i]]+x[[i+1]])/2]
,
	{i,1,Length[x]-1}
];
AppendTo[dbinsB,x[[-1]]]; (* last bin *)
);


tnb=SessionTime[];


(* This code is released under the GPL license. Copyright 2009-2014 by Valerio Marra (valerio.marra@me.com) *)
