(* ::Package:: *)

tt=SessionTime[];


(* spherical top-hat model *)
(* the following fits are from Weinberg & Kamionkowski 2003 and are valid for flat w=constant cosmologies *)

delcEdS0=3/20(12\[Pi])^(2/3); (* 1.686 - EdS prediciton but approximately valid for other cosmologies *)
alpde= 0.353 w0^4 + 1.044 w0^3 +1.128 w0^2 + 0.555 w0 + 0.131;
delc0[z_]:=delcEdS0 (1+ alpde Log[10,OmegaMz[z]]); (* accurate for 0.1< Om<1 and -1<w<-0.3 *)
delc[z_]:=delc0[z]/DDz[z];

DELTAvirEdS= 18 \[Pi]^2;
aDELTA=0.399-1.309(Abs[w0]^0.426 -1);
bDELTA=0.941-0.205(Abs[w0]^0.938 -1);
DELTAvir[z_]:=DELTAvirEdS If[OmegaMz[z]<1,(1+ aDELTA (1/OmegaMz[z] -1)^bDELTA),1];(* accurate for -1<w<-0.3 *)


(* halo mass functions *)

(* Jenkins et al. Eq.(B3) for SO(180) - valid for -0.5<Log[DEL[M,z]^-1]<1.0 *)
fJet[M_,z_]:= 0.301 dlnDELM[M] Exp[-Abs[0.64-Log[iDELM[M,z]]]^3.82] ;

(* Sheth-Tormen *)
(*AST=0.3222;aST=0.707;pST=0.3;
fST[M_,z_]:=dlnDELM[M] AST (2 aST/Pi)^(1/2) (1+(iDEL0M2[M]/(aST delc[z]^2))^pST) delc[z]/iDEL0M[M] Exp[-aST delc[z]^2/(2 iDEL0M2[M])];*)

(* Sheth-Tormen refitted by Courtin etal 2011 *)
AST=0.348;aST=0.695;pST=0.1;
fST[M_,z_]:=dlnDELM[M] AST (2 aST/Pi)^(1/2) (1+(iDEL0M2[M]/(aST delc[z]^2))^pST) delc[z]/iDEL0M[M] Exp[-aST delc[z]^2/(2 iDEL0M2[M])];

(* Press-Schechter *)
fPS[M_,z_]:=dlnDELM[M] (2/Pi)^(1/2) delc[z]/iDEL0M[M] Exp[-delc[z]^2/(2 iDEL0M2[M])];

(* Warren et al. 2006 *)
fWar[M_,z_]:= 0.7234 dlnDELM[M] (iDELM[M,z]^-1.625 + 0.2538) Exp[-1.1982/iDELM[M,z]^2] ;


(* master mass function and halo number density *)

ffm[mf_,M_,z_]:=(*ffm[mf,M,z]=*)Piecewise[{{fJet[M,z],mf==1},{fST[M,z],mf==2},{fPS[M,z],mf==3},{fWar[M,z],mf==4}}];

nhalo[M_,z_]:=ffm[mf,M,z] rhoMC/M;


(* halo radius: we define the halo according to a SO halo finder with DeltaH wrt the mean matter density *)

DeltaH=Which[mf==1,180,mf==2,200,mf==3,200,mf==4,200];
Rnp[M_,z_,del_]:=(3 M/(4\[Pi] del rhoMz[z]))^(1/3); (* in proper coordinates *)
Rn[M_,z_,del_]:=Rnp[M,z,del](z+1)/a0;(* in comoving coordinates *)


(* to calculate the mass fractions *)

DfH0=NIntegrate[ffm[mf,Mn[n],0]Mn'[n],{n,nmin,Min[{14,nmax}],nmax},Method->{Automatic,"SymbolicProcessing"->0},AccuracyGoal->5]; (* present-day \[CapitalDelta]f_H *)
DfLU0=1-DfH0; (* present-day \[CapitalDelta]f_LU *)


(* to build the bin table *)

If[
	nmin==nmax
,
	nbins=0;
	ntab={};
	ntabc={};
	ClearAll[nCONFmin];
	confinement=0;
,
	ntab=Table[n,{n,nmin,nmax,(nmax-nmin)/(nbins)}]; (* bins *)
	ntabc=Table[n+(nmax-nmin)/(2 nbins),{n,nmin,nmax-(nmax-nmin)/(nbins),(nmax-nmin)/(nbins)}]; (* bin centers *)
	nCONFmin=Last[Nearest[ntab,nCONFmin]];
	inCONFmin=Position[ntab,nCONFmin][[1,1]];
];


(* Mn[z] - for adaptive mass binning *)

nz[n0_?NumericQ,z_?NumericQ]:=nzf/.FindRoot[iDEL0n[n0]==iDEL0n[nzf]DDz[z],{nzf,n0}]; (* exact: for mass functions such as Jenkins that dont use delc0[z] *)

nzCos[n0_?NumericQ,z_?NumericQ]:=nzf/.FindRoot[iDEL0n[n0]/delc0[0]==iDEL0n[nzf]DDz[z]/delc0[z],{nzf,n0}]; (* almost exact: for mass functions such as Sheth-Tormen that do use delc0[z] *)


(* to calculate the confined halo mass fractions *)

Which[
	confinement==1
,
	If[
		nCONFmin==nmin
	,
		DfHC0=DfH0;
	,
		DfHC0=NIntegrate[ffm[mf,Mn[n],0]Mn'[n],{n,nCONFmin,Min[{14,nmax}],nmax},Method->{Automatic,"SymbolicProcessing"->0},AccuracyGoal->6]; (* present-day \[CapitalDelta]f^C_H *)
	];
	
	DfHNC0=DfH0-DfHC0; (* present-day \[CapitalDelta]f^NC_H *)
,
	confinement==0
,
	nCONFmin=nmax;
	DfHC0=0;
	DfHNC0=DfH0;
];


dtt2=SessionTime[]-tt;


(* This code is released under the GPL license. Copyright 2009-2014 by Valerio Marra (valerio.marra@me.com) *)
