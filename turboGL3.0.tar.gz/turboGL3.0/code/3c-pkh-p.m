(* ::Package:: *)

tt=SessionTime[];


(* Fourier transform of NFW halo profile *)

(* 4 \[Pi]/k Integrate[fnfw[r,Rc,c] Sin[k r] r,{r,0,Rc},GenerateConditions->False,Assumptions->{r<Rc,c>0}] *)
wNFWf[k_,Rc_,c_]:=norNFW[c]/c^3(Cos[(k Rc)/c] (-CosIntegral[(k Rc)/c]+CosIntegral[((1+c) k Rc)/c])-(c Sin[k Rc])/(k Rc+c k Rc)+Sin[(k Rc)/c] (-SinIntegral[(k Rc)/c]+SinIntegral[((1+c) k Rc)/c]));


(* Pk as explained in Peacock & Smith 2000 *)

PkHz[k_,z_]:=Module[{DfHnx,wNFWnx},
DfHnx=vTable[NIntegrate[ffm[mf,Mn[n],z]Mn'[n],{n,ntab[[in]],ntab[[in+1]]},Method->{Automatic,"SymbolicProcessing"->0},AccuracyGoal->6],{in,1,nbins}];
wNFWnx=vTable[wNFWf[k,Rn[Mn[ntabc[[in]]],z,DeltaH],cn004m[ntabc[[in]],z]],{in,1,nbins}];
Chop[Total[DfHnx Mn[ntabc[[All]]]/rhoMC wNFWnx^2]]
];

PkHzFast[k_,z_]:=Module[{DfHnx,wNFWnx},
Off[InterpolatingFunction::dmval];DfHnx=Table[iDfHn[[in]][z],{in,1,nbins}];On[InterpolatingFunction::dmval];
wNFWnx=vTable[wNFWf[k,Rn[Mn[ntabc[[in]]],z,DeltaH],cn004m[ntabc[[in]],z]],{in,1,nbins}]; (* vTable gives inconsequential errors *)
Chop[Total[DfHnx Mn[ntabc[[All]]]/rhoMC wNFWnx^2]]
];
DEL2HzFast[k_,z_]:=k^3/(2\[Pi]^2) PkHzFast[k,z];

PkHM[k_,z_]:=PkL[k,z]+ PkHz[k,z];
DEL2HM[k_,z_]:=k^3/(2\[Pi]^2) PkHM[k,z];

PkHMFast[k_,z_]:=PkL[k,z]+ PkHzFast[k,z];
DEL2HMFast[k_,z_]:=DEL2k[k,z] + DEL2HzFast[k,z];


(* shot-noise version - neglecting NFW profile *)

PkHzFastSN[k_,z_]:=Module[{DfHnx},
Off[InterpolatingFunction::dmval];DfHnx=Table[iDfHn[[in]][z],{in,1,nbins}];On[InterpolatingFunction::dmval];
Chop[Total[DfHnx Mn[ntabc[[All]]]/rhoMC]]
];
DEL2HzFastSN[k_,z_]:=k^3/(2\[Pi]^2) PkHzFastSN[k,z];


(* using the quasi-linear term with b(M)=1 - it is very close to the previous one that just uses the linear pk *)

PkHMFastQ[k_,z_]:=Module[{DfHnx,wNFWnx},
Off[InterpolatingFunction::dmval];DfHnx=Table[iDfHn[[in]][z],{in,1,nbins}];On[InterpolatingFunction::dmval];
wNFWnx=vTable[wNFWf[k,Rn[Mn[ntabc[[in]]],z,DeltaH],cn004m[ntabc[[in]],z]],{in,1,nbins}];
Chop[PkL[k,z] (Total[DfHnx wNFWnx]+(1-Total[DfHnx])(*uniform matter field*))^2 +Total[DfHnx Mn[ntabc[[All]]]/rhoMC wNFWnx^2]]
];

DEL2HMFastQ[k_,z_]:=k^3/(2\[Pi]^2) PkHMFastQ[k,z];


kutable=Table[{z,k/.FindRoot[PkL[a0 k,z]==PkHzFast[a0 k,z],{k,0.15,0.04,500}]},{z,Insert[Table[z,{z,0,zod,zod/4}],zod-zod/8,-2]}]; (* 20 for z\[LessEqual]1.5, 200 for larger z *)
kcut=Interpolation[kutable,InterpolationOrder->1];


dtt2=SessionTime[]-tt;
gtt3=dtt+dtt2;


(* This code is released under the GPL license. Copyright 2009-2014 by Valerio Marra (valerio.marra@me.com) *)
