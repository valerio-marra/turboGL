(* ::Package:: *)

(* \[CurlyPhi] AND \[CapitalGamma] functions for spherical halos *)

(* N[Integrate[4\[Pi] b^2 Exp[-b^2/(2 (RC/3)^2)]/((RC/3)^3(2\[Pi])^(3/2)),{b,0,RC},Assumptions->{RC>0}]] *)
normafGAU=0.9707091134651114;
fgau[b_,RC_]:=normafGAU^-1 Exp[-b^2/(2 (RC/3)^2)]/((RC/3)^3(2\[Pi])^(3/2)) (1-UnitStep[b-RC]);
(* N[Integrate[2\[Pi] b Exp[-(b^2/(2(RC/3)^2))]/(2\[Pi] (RC/3)^2),{b,0,RC},Assumptions->{RC>0}]] *)
normaFGAU=0.9888910034617577;
Fgau[b_,RC_]:=normaFGAU^-1 Exp[-(b^2/(2(RC/3)^2))]/(2\[Pi] (RC/3)^2) (1-UnitStep[b-RC]);
bbingau=15;
nxgau=1.1;

fsis[b_,RC_]:=(4\[Pi] b^2 RC)^-1 (1-UnitStep[b-RC]);
Fsis[b_,RC_]:=ArcCos[b/RC]/(2\[Pi] b RC) (1-UnitStep[b-RC]);
bbinsis=30;
nxsis=1.3;

funi[b_,RC_]:=3/(4\[Pi] RC^3) (1-UnitStep[b-RC]);
Funi[b_,RC_]:=3 Sqrt[RC^2-b^2]/(2\[Pi] RC^3)(1-UnitStep[b-RC]);
bbinuni=15;
nxuni=0.65;

norNFW[c_]:=c^3/(Log[1+c]-c/(1+c));
fnfw[b_,RC_,con_]:=(4\[Pi] b (RC/con+b)^2 (Log[1+con]-con/(1+con)))^-1 (1-UnitStep[b-RC]);
Fnfw[b_,RC_,con_]:=(1-UnitStep[b-RC]) con^2*(-con Sqrt[(b^2-RC^2) (b^2 con^2-RC^2)]+(1+con) RC^2 (Log[-b(1+con) RC]-Log[-b^2 con-RC^2+Sqrt[(b^2-RC^2) (b^2 con^2-RC^2)]]))/(2 \[Pi] RC (-b^2 con^2+RC^2)^(3/2) (-con+(1+con) Log[1+con]));
bbinnfw=20;
nxnfw=1.5;

(* Fxxx[b_,RC_,con_]:=Integrate[2x/Sqrt[x^2-b^2] fxxx[x,RC,con],{x,b,RC},Assumptions->{b>0,RC>b,con>0}] *)
(* Integrate[4\[Pi] b^2 fxxx[b,RC,con],{b,0,RC},Assumptions->{RC>0,con>0}]==1 *)
(* Integrate[2\[Pi] b   Fxxx[b,RC,con],{b,0,RC},Assumptions->{RC>0,con>0}]==1 *)

(* altogether *)
fS[profi_,b_,RC_,con_]:=Piecewise[{{fnfw[b,RC,con],profi==1},{fsis[b,RC],profi==2},{fgau[b,RC],profi==3},{funi[b,RC],profi==4}}];
FS[profi_,b_,RC_,con_]:=Piecewise[{{Fnfw[b,RC,con],profi==1},{Fsis[b,RC],profi==2},{Fgau[b,RC],profi==3},{Funi[b,RC],profi==4}}];
bbinsS[profi_]:=Piecewise[{{bbinnfw,profi==1},{bbinsis,profi==2},{bbingau,profi==3},{bbinuni,profi==4}}];
nxS[profi_]:=Piecewise[{{nxnfw,profi==1},{nxsis,profi==2},{nxgau,profi==3},{nxuni,profi==4}}];


(* \[CurlyPhi] functions for cylindrical filaments *)

(* N[Integrate[LC 2\[Pi] b  Exp[-b^2/(2 (RC/3)^2)]/(LC 2\[Pi] (RC/3)^2),{b,0,RC},Assumptions->{RC>0}]] *)
normafGAUF=0.9888910034617577;
fgauF[b_,RC_,LC_]:=normafGAUF^-1 Exp[-b^2/(2 (RC/3)^2)]/(LC 2\[Pi] (RC/3)^2) (1-UnitStep[b-RC]);

funiF[b_,RC_,LC_]:=(\[Pi] RC^2 LC)^-1 (1-UnitStep[b-RC]);

(* Integrate[LC 2\[Pi] b fxxxF[b,RC,LC],{b,0,RC},Assumptions->{RC>0}]==1 *)

(* altogether *)
fC[profi_,b_,RC_,LC_]:=Piecewise[{{fgauF[b,RC,LC],profi==3},{funiF[b,RC,LC],profi==4}}];


(* \[CapitalGamma] functions for cylindrical filaments - for \[Theta]=0 *)

FgauF1[b_,RC_,LC_]:=LC fgauF[b,RC,LC] (1-UnitStep[b-RC]);
bbingauF1=13;
nxgauF1=1.1;

FuniF1[b_,RC_,LC_]:=LC funiF[b,RC,LC] (1-UnitStep[b-RC]);
bbinuniF1=14;
nxuniF1=0.5;

(* Integrate[2\[Pi] b FxxxF1[b,RC,LC,theta],{b,0,RC},Assumptions->{RC>0}]==1 *)

(* altogether *)
FC1[profi_,b_,RC_,LC_]:=Piecewise[{{FgauF1[b,RC,LC],profi==3},{FuniF1[b,RC,LC],profi==4}}];
bbinsC1[profi_]:=Piecewise[{{bbingauF1,profi==3},{bbinuniF1,profi==4}}];
nxC1[profi_]:=Piecewise[{{nxgauF1,profi==3},{nxuniF1,profi==4}}];


(* \[CapitalGamma] functions for cylindrical filaments - for \[Theta]>10 *)

(* N[LC Sin[theta] 2Integrate[ Exp[-b^2/(2 (RC/3)^2)]/(Sin[theta]LC Sqrt[2 \[Pi]] RC/3),{b,0,RC},Assumptions->{RC>0}]] *)
normaFGAUF=0.9973002039367398;
FgauF2[b_,RC_,LC_,theta_]:=normaFGAUF^-1 Exp[-b^2/(2 (RC/3)^2)]/(Sin[theta]LC Sqrt[2 \[Pi]] RC/3) (1-UnitStep[b-RC]);
bbingauF2=15;
nxgauF2=1.7;

FuniF2[b_,RC_,LC_,theta_]:=funiF[b,RC,LC] 2 Sqrt[RC^2-b^2]/Sin[theta] (1-UnitStep[b-RC]);
bbinuniF2=16;
nxuniF2=1.2;

(* N[LC Sin[theta] 2 Integrate[FxxxF2[b,RC,LC,theta],{b,0,RC},Assumptions->{RC>0}]]==1 *)

(* altogether *)
FC2[profi_,b_,RC_,LC_,theta_]:=Piecewise[{{FgauF2[b,RC,LC,theta],profi==3},{FuniF2[b,RC,LC,theta],profi==4}}];
bbinsC2[profi_]:=Piecewise[{{bbingauF2,profi==3},{bbinuniF2,profi==4}}];
nxC2[profi_]:=Piecewise[{{nxgauF2,profi==3},{nxuniF2,profi==4}}];


(* This code is released under the GPL license. Copyright 2009-2014 by Valerio Marra (valerio.marra@me.com) *)
