(* ::Package:: *)

tt=SessionTime[];


(* r bins *)

irmin=1;(* 2 is ok and anyway 1<=irmin<=3 *)
rbins=12; (* 12 is ok *)
rs=rz[zod]; der=rs/rbins;

ri[ir_]:=ir der; (* ri[rbins]=rs *)
rib[ir_]:=(ir-1/2) der; (* rib[rbins]=rs-der/2 *)

Ggb=Table[NIntegrate[Gg[r,rs],{r,ri[ir-1],ri[ir]},Method->{Automatic,"SymbolicProcessing"->0}]/der,{ir,irmin,rbins}];
zsl=Table[zr[rib[ir]],{ir,irmin,rbins}];


(* halo binning *)

haloBinning=
vTable[
	If[ib==1,
		MnLOC=Mn[ntabc[[in]]];
		DfHnLOC=NIntegrate[ffm[mf,Mn[n],zsl[[ir]]]Mn'[n],{n,ntab[[in]],ntab[[in+1]]},Method->{Automatic,"SymbolicProcessing"->0},AccuracyGoal->6];
		DnHnLOC=DfHnLOC rhoMC/MnLOC;
		RxnLOC=Rn[MnLOC,zsl[[ir]],DeltaH];
		conLOC=cn004m[ntabc[[in]],zsl[[ir]]];
	,Null];

		bm1=RxnLOC ((ib-1)/bbinnfw)^nxnfw;bm2=RxnLOC (ib/bbinnfw)^nxnfw;
		DaLOC=\[Pi] bm2^2 -\[Pi] bm1^2;
		GaLOC=Re[NIntegrate[Fnfw[b,RxnLOC,conLOC] 2\[Pi] b,{b,bm1,bm2},Method->{Automatic,"SymbolicProcessing"->0}]]/DaLOC;

		selLOC=1;
		kappa1LOC= Ggb[[ir]] MnLOC GaLOC;
		denLOC= der DnHnLOC DaLOC;

		{kappa1LOC,denLOC,selLOC,DnHnLOC,DfHnLOC,(* these are just for checks -> *)GaLOC,DaLOC}

,{ir,irmin,rbins},{in,1,nbins},{ib,1,bbinnfw}];

kappa1H=haloBinning[[All,All,All,1]];
denH=haloBinning[[All,All,All,2]];
selH=haloBinning[[All,All,All,3]];

DnHn=haloBinning[[All,All,1,4]];
DfHn=haloBinning[[All,All,1,5]];
DfH=Total[DfHn,{2}];
iDfHn={};
Do[AppendTo[iDfHn,Interpolation[Partition[Riffle[zsl,DfHn[[All,in]]],2],InterpolationOrder->3]];,{in,1,nbins}];
(* Clear[haloBinning] *)


(* spherical obj binning *)

objsSBinning=
vTable[
	If[io==1,
		DfLULOC=1-DfH[[ir]];
		DfLLOC=betaS DfLULOC;

		MLOC=Mn[objsS[[All,2]]];
		DnLLOC=DfLLOC rhoMC/MLOC;

		RxLOC=objsS[[All,3]](Boole[Thread[objsS[[All,4]]==0]](zsl[[ir]]+1)/a0 + Boole[Thread[objsS[[All,4]]==1]]1/a0);
		VfLOC=4 \[Pi]/3 RxLOC^3;

		Which[
			cro==1,
			qfLOC=VfLOC DnLLOC; (* volume fraction occupied by the low-contrast objects *)
			psiLOC=ConstantArray[1,NobjS];
		,
			cro==0,
			qfLOC=1-Exp[-VfLOC DnLLOC]; (* volume fraction occupied by the low-contrast objects *)
			psiLOC=qfLOC/(VfLOC DnLLOC); (* correction due to crossings *)
		];
	,Null];

		bbins=bbinsS[objsS[[io,7]]];nx=nxS[objsS[[io,7]]];
		xb[ib_]=(ib/bbins)^nx;
	Table[	
		bm1=RxLOC[[io]] xb[ib-1];bm2=RxLOC[[io]] xb[ib];
		DaLOC=\[Pi] bm2^2 -\[Pi] bm1^2;
		GaLOC=Re[NIntegrate[FS[objsS[[io,7]],b,RxLOC[[io]],objsS[[io,8]]] 2\[Pi] b,{b,bm1,bm2},Method->{Automatic,"SymbolicProcessing"->0}]]/DaLOC;
		Dereff=VfLOC[[io]] GaLOC;
		selLOC=1;
		kappa1LOC= Ggb[[ir]] MLOC[[io]] GaLOC;
		denLOC= der DnLLOC[[io]] DaLOC;

		{kappa1LOC,denLOC,selLOC,Dereff,qfLOC[[io]],psiLOC[[io]],(* these are just for checks -> *)DnLLOC[[io]],DfLLOC[[io]],GaLOC,DaLOC}

	,{ib,1,bbins}]

,{ir,irmin,rbins},{io,1,NobjS}];

kappa1S=objsSBinning[[All,All,All,1]];
denS=objsSBinning[[All,All,All,2]];
selS=objsSBinning[[All,All,All,3]];
DereffS=objsSBinning[[All,All,All,4]];
qfS=objsSBinning[[All,All,1,5]];
psiS=objsSBinning[[All,All,1,6]];
(* Clear[objsSBinning] *)


(* cylindrical obj binning *)

tbins=8;tbinsE=tbins/2+1;(* \[Theta] bins *)
theta[t_]= \[Pi]/2 (t-1)/(tbinsE-1);
NobjCE=Length[objsC]tbinsE;

objsCBinning=
vTable[
	If[io==1,
		DfLULOC=1-DfH[[ir]];
		DfLLOC=betaC DfLULOC;

		MLOC=Mn[objsC[[All,2]]];
		DnLLOC=DfLLOC rhoMC/MLOC;

		RxLOC=objsC[[All,3]](Boole[Thread[objsC[[All,4]]==0]](zsl[[ir]]+1)/a0 + Boole[Thread[objsC[[All,4]]==1]]1/a0);
		LxLOC=objsC[[All,5]](Boole[Thread[objsC[[All,6]]==0]](zsl[[ir]]+1)/a0 + Boole[Thread[objsC[[All,6]]==1]]1/a0);
		VfLOC=\[Pi] RxLOC^2 LxLOC;

		Which[
			cro==1,
			qfLOC=VfLOC DnLLOC; (* volume fraction occupied by the low-contrast objects *)
			psiLOC=ConstantArray[1,NobjC];
		,
			cro==0,
			qfLOC=1-Exp[-VfLOC DnLLOC]; (* volume fraction occupied by the low-contrast objects *)
			psiLOC=qfLOC/(VfLOC DnLLOC); (* correction due to crossings *)
		];
	,Null];

		iov=Ceiling[io/tbinsE]; (* iov labels the families of cylinders, io labels the families of \[Theta]-cylinders *)
		thetaLOC=theta[Mod[io,tbinsE,1]];

		bbins=If[thetaLOC==0,bbinsC1[objsC[[iov,7]]],bbinsC2[objsC[[iov,7]]]];
		nx=If[thetaLOC==0,nxC1[objsC[[iov,7]]],nxC2[objsC[[iov,7]]]];
		xb[ib_]=(ib/bbins)^nx;
	Table[	
		If[
			thetaLOC==0
		,
			DfLELOC=DfLLOC[[iov]]/tbins;
			DnLELOC=DnLLOC[[iov]]/tbins;
			bm1=RxLOC[[iov]] xb[ib-1];bm2=RxLOC[[iov]] xb[ib];
			DaLOC=\[Pi] bm2^2 -\[Pi] bm1^2;
			GaLOC=Re[NIntegrate[FC1[objsC[[iov,7]],b,RxLOC[[iov]],LxLOC[[iov]]] 2\[Pi] b,{b,bm1,bm2},Method->{Automatic,"SymbolicProcessing"->0}]]/DaLOC;
			Dereff=VfLOC[[iov]] GaLOC;
			selLOC=1;(* always 1 *)
			kappa1LOC= Ggb[[ir]] MLOC[[iov]] GaLOC;
			denLOC= der DnLELOC DaLOC;
		,
			DfLELOC=DfLLOC[[iov]] If[thetaLOC==\[Pi]/2,1,2]/tbins;
			DnLELOC=DnLLOC[[iov]] If[thetaLOC==\[Pi]/2,1,2]/tbins;
			bm1=RxLOC[[iov]] xb[ib-1];bm2=RxLOC[[iov]] xb[ib];
			LxELOC=LxLOC[[iov]]Sin[thetaLOC];
			DaLOC=LxELOC 2(bm2 - bm1);
			GaLOC=2 LxELOC Re[NIntegrate[FC2[objsC[[iov,7]],b,RxLOC[[iov]],LxLOC[[iov]],thetaLOC],{b,bm1,bm2},Method->{Automatic,"SymbolicProcessing"->0}]]/DaLOC;
			Dereff=VfLOC[[iov]] GaLOC;
			selLOC=1;
			kappa1LOC= Ggb[[ir]] MLOC[[iov]] GaLOC;
			denLOC= der DnLELOC DaLOC;
		];

		{kappa1LOC,denLOC,selLOC,Dereff,qfLOC[[iov]],psiLOC[[iov]],(* these are just for checks -> *)DnLELOC,DfLELOC,GaLOC,DaLOC}

	,{ib,1,bbins}]

,{ir,irmin,rbins},{io,1,NobjCE}];

kappa1C=objsCBinning[[All,All,All,1]];
denC=objsCBinning[[All,All,All,2]];
selC=objsCBinning[[All,All,All,3]];
DereffC=objsCBinning[[All,All,All,4]];
qfC=objsCBinning[[All,Table[1+tbinsE (j-1),{j,1,NobjC}],1,5]];
psiC=objsCBinning[[All,All,1,6]];
(* Clear[objsCBinning] *)


(* total comoving average volume fractions *)

qfa=Total[qfS,{2}]+Total[qfC,{2}];


(* to join the tables *)

kappa1=Join[kappa1H,kappa1S,kappa1C,2];
den=Join[denH,denS,denC,2];
sel=Join[selH,selS,selC,2];


(* \[Kappa]u, \[Kappa]ue and \[Kappa]e *)

kappaUE=-Total[kappa1 den,3];
kappaU=rhoMC der Total[Ggb (1-DfH)](1-betaTOT);
kappaE=kappaUE-kappaU;

DfUi[z_]=Fit[Partition[Riffle[zsl,(1-betaTOT)(1-DfH)],2],{1,z,z^2,z^3},z];
kauU[rs_]:=Quiet[rhoMC NIntegrate[Gg[r,rs] DfUi[zr[r]],{r,0,rs},Method->{Automatic,"SymbolicProcessing"->0}]];
kauUE[rs_]:=kauU[rs]+kauE[rs];

(* {kappaE,kappaU,kappaUE}=={kauE[rs],kauU[rs],kauUE[rs]} *)


(* mean, variance and skewness *)

kappaMean=Total[kappa1 den(sel-1),3];

kappaVar=1/NOz Total[kappa1^2 den sel,3]; (* correct only without confinement *)
kappaSigma=kappaVar^0.5;

kappa3moment=Total[kappa1^3 den sel,3]; (* CentralMoment[kappaSIM,3] *)


(* variance of \[Kappa] per halo or obj *)

kappaVarH=1/NOz Total[Total[kappa1H^2 denH selH,{3}],{1}];
kappaSigmaH=kappaVarH^0.5;

kappaVarS=1/NOz Total[Total[kappa1S^2 denS selS,{3}],{1}];
kappaSigmaS=kappaVarS^0.5;

kappaVarCt=1/NOz Total[Total[kappa1C^2 denC selC,{3}],{1}];
kappaVarC=Table[Total[kappaVarCt[[(j-1)tbinsE+1;;j tbinsE]]],{j,1,NobjC}];
kappaSigmaC=kappaVarC^0.5;


dtt=SessionTime[]-tt;


(* This code is released under the GPL license. Copyright 2009-2014 by Valerio Marra (valerio.marra@me.com) *)
