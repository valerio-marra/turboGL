(* ::Package:: *)

tt=SessionTime[];


(* window functions *)

wf=1;(* 1 for top-hat window function, 2 for gaussian window function *)

wth[y_]:=If[y>10^-3,3(Sin[y]/y^3 - Cos[y]/y^2),1]; (* Limit[3(Sin[y]/y^3 - Cos[y]/y^2),y\[Rule]0] *)
wgau[y_]:=Exp[-y^2 /2];
wdirac[y_]:=Sin[y]/y;

wfun[wf_,y_]:=Piecewise[{{wth[y],wf==1},{wgau[y],wf==2}}];


(* transfer function - works for any curvature and cosmological constant *)
(* Eisenstein & Hu 1998 - effective shape: Eqs.(28-31) - no massive neutrinos and so no z-dependence *)

fB=OmegaB0/OmegaM0;
ss=44.5 Log[9.83/(OmegaM0 hh^2)]/Sqrt[1+10(fB OmegaM0 hh^2)^(3/4)];
alphaG=1-0.328 Log[431 OmegaM0 hh^2]fB+0.38 Log[22.3 OmegaM0 hh^2]fB^2;

Tcmb=2.725;tcmb=Tcmb/2.7;
Gamma0=OmegaM0 hh;
GammaEff[k_]:=hh Gamma0 (alphaG+(1-alphaG)/(1+(0.43 k ss)^4));

qq[k_]:=k/GammaEff[k] tcmb^2;
Lfq[k_]:=Log[2E+1.8 qq[k]];
Cfq[k_]:=14.2 +731/(1+62.5 qq[k]);

TrfFit[L_,C_,q_]:= L/(L+C q^2);
Trf[k_]=TrfFit[Lfq[k],Cfq[k],qq[k]];


(* growth function and growth rate assuming that dark energy does not cluster *)

(* fits and approximations *)
fLambda[z_]:=OmegaMz[z]^(6/11 + 15/11^3 (1-OmegaMz[z])); (*6/11 is correct only in the limit of small (1-Om) *) (* Wang & Steinhardt 1998 *)
fwCDM[z_]:=OmegaMz[z]^(0.55+0.05(1+ww[1])); (* Linder 2005 *)

zini=100; (* 30 *)
(* DDf'[zini]=-(1+zini)^-2 :  matter domination, EdS value D=1/(1+z). remark: zini=500 is no good due to radiation which here is neglected *)
Which[
	gammaGro==-10
,
	aux=NDSolve[{DDf''[z] (1+z)^2 + 1/2 DDf'[z](1+z)(OmegaMz[z]+(3 ww[z]+1)OmegaQz[z]) - 3/2 DDf[z] OmegaMz[z]==0,
	DDf'[zini]==-(1+zini)^-2,DDf[zini]==(1+zini)^-1},DDf,{z,0,zini},MaxStepFraction->1/100];
	DDzx[z_]=First[Evaluate[DDf[z]/.aux]];
	DD0=DDzx[0];
	DDz[z_]:=DDzx[z]/DD0; (* growth function *)
	
	ffz[z_]:=-(1+z)/DDz[z] DDz'[z]; (* growth rate *)
,
	gammaGro==-11
,
	dzf=.2;zfMax=zini+dzf;zfMaxFree=1; (* with .2 error of ~.15% when reconstructing D *)
	Dimensions[zfTab=Table[z,{z,0,zfMax,dzf}]];
	Dimensions[fTab=Table[{z,fLambda[z]},{z,dzf/2,zfMax-dzf/2,dzf}]];
	izfreeMax=Length[zfTabFreeCenter=Table[z,{z,dzf/2,zfMaxFree-dzf/2,dzf}]];
	Do[If[GrowthRate[[i]]!=9,fTab[[i,2]]=GrowthRate[[i]]],{i,1,izfreeMax}];(*fTab[[1;;5,2]]=GrowthRate;*) (* to alter the first bins *)
	ffz[z_(*?NumericQ*)]:=fTab[[Floor[z/dzf]+1,2]];
	
	DDzpw[z_(*?NumericQ*)]:=Product[((1+zfTab[[i+1]])/(1+zfTab[[i]]))^-fTab[[i,2]],{i,1,Floor[z/dzf],1}]
	((1+z)/(1+zfTab[[Floor[z/dzf]+1]]))^-fTab[[Floor[z/dzf]+1,2]];
	DD0=(1+zini)^-1/DDzpw[zini]; (* I know that the unnormalized D is D=1/(1+z) for large z (EdS) *)

	(* interpolation *)
	nzDbin=15; zbaba=1.5;
	tabD1=Table[Exp[x]-1,{x,Log[0+1],Log[zbaba+1],(Log[zbaba+1]-Log[0+1])/nzDbin}];
	tabD2=Table[Exp[x]-1,{x,Log[zbaba+1],Log[zini+1],(Log[zini+1]-Log[zbaba+1])/nzDbin}];
	tabD=Join[tabD1,tabD2[[2;;]]];
	magicabula=Partition[Riffle[tabD,Log[DDzpw/@tabD]],2];
	DDzAux=Interpolation[magicabula,Method->"Spline"];
	DDz[z_]=Exp[DDzAux[z]]; (* log function and log bins *)
,
	gammaGro>-10
,
	ffz[z_]:=OmegaMz[z]^gammaGro;

	DDzINT[z_]:=Exp[-NIntegrate[ffz[zi]/(1+zi),{zi,0,z},Method->{Automatic,"SymbolicProcessing"->0}]];
	DDz[z_]=Exp[First[lnDnum[z]/.NDSolve[{lnDnum'[z]==-ffz[z]/(1+z),lnDnum[0]==0},lnDnum,{z,0,zini},MaxStepFraction->1/ACCU]]];
	DD0=(1+zini)^-1/DDz[zini]; (* I know that the unnormalized D is D=1/(1+z) for large z (EdS) *)
];


(* coversion from amplitude of scalar perturbation to amplitude of density perturbations *)

(*kpivot=0.05;*)(* Mpc^-1 *) (* 0.05 for Planck, 0.002 for WMAP *)
DtoR= 25/4(OmegaM0/DD0)^2 (kpivot/kh0)^(nsp-1);
RtoD=1/DtoR;


(* power spectrum and normalization *)

klbound=10^-6;
DEL2k0unnorm[k_]:=(cc k/(a0 H0))^(3+nsp) Trf[k/a0]^2;
r8=8/hh/a0; (* comoving scale of 8 Mpc/h *)
norms8=NIntegrate[DEL2k0unnorm[a0 kp]/kp wfun[wf,kp a0 r8]^2,{kp,klbound,Infinity},Method->{Automatic,"SymbolicProcessing"->0}];

ClearAll[sig8,delh,As];
Which[
	normaPk==0
,
	sig8=0.832 (0.25/OmegaM0)^0.41; (* Rozo et al. 2010 *)
	delh=sig8/norms8^(1/2);
	As=delh^2 DtoR;
,
	normaPk>0.01
,
	sig8=normaPk;
	delh=sig8/norms8^(1/2);
	As=delh^2 DtoR;
,
	0<normaPk<0.01
,
	As=normaPk;
	delh=(As RtoD)^.5;
	sig8=delh norms8^(1/2);
,
	normaPk<0
,
	delh=-normaPk;
	sig8=delh norms8^(1/2);
	As=delh^2 DtoR;
];

sig8z[z_]:= sig8 DDz[z];
fsig8z[z_]:= ffz[z] sig8z[z];
fsig8zLambda[z_]:= fLambda[z] sig8 DDLambdaz[z];

DEL2k0[k_]:=delh^2 DEL2k0unnorm[k];
DEL2k[k_,z_]:=DEL2k0[k] DDz[z]^2;
PkL[k_,z_]:=DEL2k[k,z] 2\[Pi]^2/k^3;


(* mass variance *)

DEL20r[r_]:=(*DEL20r[r]=*)NIntegrate[DEL2k0[a0 kp]/kp wfun[wf,kp a0 r]^2,{kp,klbound,Infinity},Method->{Automatic,"SymbolicProcessing"->0},MaxRecursion->20,AccuracyGoal->5];
DEL2r[r_,z_]:=DDz[z]^2 DEL20r[r];

rM[M_]:=(3 M/ (4 Pi rhoMC))^(1/3);
Mr[r_]:=4/3 Pi rhoMC r^3;
Mn[n_]:=10^n hh^-1;
nM[M_]:= Log[10, hh M];

DEL20[M_]:=DEL20r[rM[M]];
DEL0[M_]:=DEL20[M]^(1/2);
DEL2[M_,z_]:=DEL2r[rM[M],z];
DEL[M_,z_]:=DEL2[M,z]^(1/2);


(* fits for \[Sigma](M) and its log derivative *)

n1=-2;n2=19;nsmin=-10;
DEL0tab=vTable[{n,DEL0[Mn[n]]},{n,Prepend[Table[n,{n,n1,n2}],nsmin]}]; (* fit valid for M_n1 <M< M_n2 *)
iDEL0n=Interpolation[DEL0tab,InterpolationOrder->3];

iDEL0M[M_]=iDEL0n[nM[M]];
iDEL0M2[M_]:=iDEL0M[M]^2;

iDELM[M_,z_]:=iDEL0M[M] DDz[z];
iDELM2[M_,z_]:=iDELM[M,z]^2;

dlnDELM[M_]:=-iDEL0n'[nM[M]]/iDEL0n[nM[M]] nM'[M];
dlnDELn[n_]:=-iDEL0n'[n]/iDEL0n[n] /Mn'[n];


dtt=SessionTime[]-tt;


(* This code is released under the GPL license. Copyright 2009-2014 by Valerio Marra (valerio.marra@me.com) *)
