(* ::Package:: *)

(* halo mass function plots *)

exp=1;
fp1=Plot[{Mn[n]^exp ffm[mf,Mn[n],0],Mn[n]^exp ffm[mf,Mn[n],0.5],Mn[n]^exp ffm[mf,Mn[n],1.5]},{n,10,16},Axes->False,Frame->True,
PlotPoints->pp,MaxRecursion->rr,FrameStyle->fst,PlotRange->All,PlotStyle->{Red,Green,Blue},FrameLabel->{"n",None,"M f(M) at z=0 (red), z=0.5 (green) and z=1.5 (blue)"}];

exp=5/3;
fp2=Plot[{Mn[n]^exp ffm[mf,Mn[n],0],Mn[n]^exp ffm[mf,Mn[n],0.5],Mn[n]^exp ffm[mf,Mn[n],1.5]},{n,10,16},Axes->False,Frame->True,
PlotPoints->pp,MaxRecursion->rr,FrameStyle->fst,PlotRange->All,PlotStyle->{Red,Green,Blue},FrameLabel->{"n",None,"\!\(\*SuperscriptBox[\(M\), \(5/3\)]\)f(M) at z=0 (red), z=0.5 (green) and z=1.5 (blue)"}];


(* growth rate and function plots *)

(*DDLambdaz[z_]:=Exp[-NIntegrate[fLambda[zi]/(1+zi),{zi,0,z},Method->{Automatic,"SymbolicProcessing"->0}]];*)
DDLambdaz[z_]=Exp[First[lnDnum[z]/.NDSolve[{lnDnum'[z]==-fLambda[z]/(1+z),lnDnum[0]==0},lnDnum,{z,0,zini},MaxStepFraction->1/ACCU]]];

grp1=Plot[{ffz[z],fLambda[z]},{z,0,3},PlotStyle->{{Thick,Dotted,Black},Red},Frame->True,FrameStyle->fst,Axes->False,PlotRange->All,FrameLabel->{"z","\!\(\*SubscriptBox[\(f\), \(g\)]\)","Actual (dotted) and \[CapitalLambda]CDM (red)"},ImageSize->450];
grp2=Plot[{DDz[z],DDLambdaz[z]},{z,0,3},PlotStyle->{{Thick,Dotted,Black},Red},Frame->True,FrameStyle->fst,Axes->False,PlotRange->All,FrameLabel->{"z","G","Actual (dotted) and \[CapitalLambda]CDM (red)"},ImageSize->450];

grp3a=Plot[{fsig8z[z],fsig8zLambda[z]},{z,0,3},PlotStyle->{{Thick,Dotted,Black},Red},Frame->True,FrameStyle->fst,Axes->False,PlotRange->All,FrameLabel->{"z","\!\(\*SubscriptBox[\(\!\(\*SubscriptBox[\(f\), \(g\)]\)\[Sigma]\), \(8\)]\)","Actual (dotted) and \[CapitalLambda]CDM (red)"},ImageSize->450];
grp3=If[gammaGro==-11,Show[grp3a,DiscretePlot[fsig8z[z],{z,dzf/2,3-dzf/2,dzf},PlotMarkers->{Automatic,Medium}]],grp3a];


(* MAH plots *)

(*nctab={10,11,12,13,14,15};
crange=Table[Blend[{Blue,Red},i],{i,1,0,-1/(Length[nctab]-1)}];
hp1a=Plot[Evaluate[vTable[nAH[z,n,0],{n,nctab}]],{z,0,5},Axes->False,Frame->True,PlotPoints->pp,MaxRecursion->rr,FrameStyle->fst,
PlotStyle->crange,FrameLabel->{"z",None,"Mass accretion history (solid) and \[CapitalDelta]f=const bins (dotted)"}];
crange2=Table[{Blend[{Blue,Red},i],Dotted},{i,1,0,-1/(Length[nctab]-1)}];
hp1b=Plot[Evaluate[Table[nz[n,z],{n,nctab}]],{z,0,2},Axes->False,Frame->True,PlotPoints->pp,MaxRecursion->rr,FrameStyle->fst,
PlotStyle->crange2];
hp1=Show[hp1a,hp1b];*)

hp2a=ListLogPlot[vTable[{n,cn004m[n,0]},{n,10,16,1}],Axes->False,Frame->True,FrameStyle->fst,
Joined->True,PlotStyle->{Thick,Green},InterpolationOrder->3];
hp2b=ListLogPlot[vTable[{n,cn004m[n,1.5]},{n,10,16,1}],Axes->False,Frame->True,FrameStyle->fst,
Joined->True,PlotStyle->{Thick,Orange},InterpolationOrder->3];
hp2=Show[hp2a,hp2b,PlotRange->All,FrameLabel->{"n",None,"Concent. param. c at z=0 (green) and at z=1.5 (orange)"}];


(* to get the halo bin mass fractions today *)

results=
vTable[
	DfHn0LOC=NIntegrate[ffm[mf,Mn[n],0]Mn'[n],{n,ntab[[i]],ntab[[i+1]]},Method->{Automatic,"SymbolicProcessing"->0},AccuracyGoal->6];
	DnHn0LOC=DfHn0LOC rhoMC/Mn[ntabc[[i]]];
	{DfHn0LOC,DnHn0LOC}
,
	{i,1,nbins}
];

DfHn0=results[[All,1]];
DnHn0=results[[All,2]];

etest=Abs[Total[DfHn0]-DfH0];
If[etest>0.001,Print["!!!WARNING!! check NIntegrate"],Null];


(* to generate the summary table *)

haloTab=
Table[
{
	M[Round[ntabc[[i]],0.01]],
	Round[cn004m[ntabc[[i]],0],.1],
	Row[{M[Round[ntab[[i]],.01]],"\[LongDash]",M[Round[ntab[[i+1]],.01]]}],
	nneat[DfHn0[[i]]],
	DeltaH,
	nneat[hh Rnp[Mn[ntabc[[i]]],0,DeltaH]],
	If[Chop[DnHn0[[i]],chip]!=0,nneat[hh DnHn0[[i]]^(-1/3)a0],"-"],
	nneat[DnHn0[[i]](500/hh/a0 + 2 Rn[Mn[ntabc[[i]]],0,DeltaH])^3],
	If[ntab[[i]]<nCONFmin,"not confined","confined"]
}
,
	{i,1,nbins}
];

uniTab={{"\!\(\*SubscriptBox[\(\[Rho]\), \(MU\)]\)","-","-",nneat[DfU0],"-","-","-","-","-"}};

haloLabels=
{
"",
"c",
"\[CapitalDelta]M bin",
"\[CapitalDelta]f",
"\!\(\*SubscriptBox[\(\[CapitalDelta]\), \(m\)]\)",
"\!\(\*SubscriptBox[\"R\", \"p\"]\)(\!\(\*SuperscriptBox[\"h\", RowBox[{\"-\", \"1\"}]]\)Mpc)",
"\!\(\*SubscriptBox[\"\[Lambda]\", \"P\"]\)(\!\(\*SuperscriptBox[\"h\", RowBox[{\"-\", \"1\"}]]\)Mpc)",
"\[CapitalDelta]n \!\(\*SubscriptBox[\"V\", \"500\"]\)",
"confinement"
};

lssTab=
Table[
{
	M[Round[objs[[i,2]],0.01]],
	Round[Log[10,hh MDL0[[i]]],.01],
	nneat[DfL0[[i]]],
	Row[{"{",nneat[deltas[[i]]],", ",nneat[deltaDress[[i]]],"}"}],
	Round[hh objs[[i,3]],.01],
	Round[hh objs[[i,5]],.01],
	If[Chop[DnL0[[i]],chip]!=0,nneat[hh DnL0[[i]]^(-1/3)a0],"-"],
	nneat[DnL0[[i]](500/hh/a0)^3],
	nneat[qfb0[[i]]],
	nneat[qfbz[[i]]]
}
,
	{i,1,Nobj}
];

lssLabels=
{
"",
"\!\(\*SubscriptBox[\(M\), \(D\)]\)",
"\[CapitalDelta]f",
"{\[CapitalDelta], \!\(\*SubscriptBox[\(\[CapitalDelta]\), \(D\)]\)}",
"\!\(\*SubscriptBox[\"R\", \"p\"]\)(\!\(\*SuperscriptBox[\"h\", RowBox[{\"-\", \"1\"}]]\)Mpc)",
"\!\(\*SubscriptBox[\"L\", \"p\"]\)(\!\(\*SuperscriptBox[\"h\", RowBox[{\"-\", \"1\"}]]\)Mpc)",
"\!\(\*SubscriptBox[\"\[Lambda]\", \"P\"]\)(\!\(\*SuperscriptBox[\"h\", RowBox[{\"-\", \"1\"}]]\)Mpc)",
"\[CapitalDelta]n \!\(\*SubscriptBox[\"V\", \"500\"]\)",
"\!\(\*SubscriptBox[\(q\), \(f\)]\)(0)",
"\!\(\*SubscriptBox[\(q\), \(f\)]\)(1.5)"
};

su1tab=TableForm[Join[haloTab,uniTab],TableHeadings->{None,haloLabels},TableSpacing->{1,3},TableAlignments->Center];
su2tab=TableForm[lssTab,TableHeadings->{None,lssLabels},TableSpacing->{1,3},TableAlignments->Center];


Print[Column[{
Row[{"\!\(\*SubscriptBox[\(\[Sigma]\), \(8\)]\)=",Round[sig8,0.001],"   -   \!\(\*SubscriptBox[\"\[Delta]\", \"H0\"]\)=",nneat[1. delh],"   -   \!\(\*SubscriptBox[\(A\), \(S\)]\)=",nneat[1. As],
"            -            time used=",Round[dtt+dtt2+dtt3,.01],"s"}],
"",
su1tab,"",If[lssTab=={},Null,su2tab],
"",
"",
GraphicsGrid[{{fp1,fp2},{hp2,grp3},{grp2,grp1}},Spacings->{Scaled[-0.04],Scaled[0.02]},ImageSize->920]
}]];


(* This code is released under the GPL license. Copyright 2009-2014 by Valerio Marra (valerio.marra@me.com) *)
