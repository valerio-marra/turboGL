(* ::Package:: *)

(* stochastic simulation: the core of it all! *)


tt=SessionTime[];
ncores=Min[If[$KernelCount==0,1,$KernelCount],rbins-irmin+1];


nsts=Ceiling[Sqrt[nst]];nst=nsts^2;

If[nhits==1,kimSIMcount=ConstantArray[0,{rbins-irmin+1,nbins,nst}];,Null];


(*kts=Count[kappa1,_Real,{3}]; (* it doesn't work if there's an integer entry. In case use Count[kappa1,x_/;x \[Element] Reals,{3}] *)
ttx=TimeUsed[];
If[ir==irmin&&io==1&&ib==7,PrintTemporary["The stochastic simulation will end in ",Round[(TimeUsed[]-ttx)/ib (kts-ib),.1]," s"],Null];*)


If[confinement==0,

simTab=
vTable[
	If[ir==irmin,ttx=SessionTime[],Null];

	kapSIM=ConstantArray[0,nst];

	Do[(* spherical objs *)
		kimSIM=RandomVariate[PoissonDistribution[NOz selS[[ir,io,ib]] denS[[ir,io,ib]]],nst]; (* i could remove selS and selC, no selection from them*)
		kapSIM+=kappa1S[[ir,io,ib]] (kimSIM/NOz-denS[[ir,io,ib]]);
	,
		{io,1,NobjS}
	,
		{ib,1,bbinsS[objsS[[io,7]]]}
	];

	Do[(* cylindrical objs *)
		kimSIM=RandomVariate[PoissonDistribution[NOz selC[[ir,io,ib]] denC[[ir,io,ib]]],nst];
		kapSIM+=kappa1C[[ir,io,ib]] (kimSIM/NOz-denC[[ir,io,ib]]);
	,
		{io,1,NobjCE}
	,
		{ib,1,If[theta[Mod[io,tbinsE,1]]==0,bbinsC1[objsC[[Ceiling[io/tbinsE],7]]],bbinsC2[objsC[[Ceiling[io/tbinsE],7]]]]}
	];

	Do[(* halos *)
		kimSIM=RandomVariate[PoissonDistribution[NOz selH[[ir,in,ib]] denH[[ir,in,ib]]],nst];
		kapSIM+=kappa1H[[ir,in,ib]] (kimSIM/NOz-denH[[ir,in,ib]]);
		If[nhits==1,kimSIMcount[[ir,in]]+=kimSIM;,Null];
	,
		{in,1,nbins}
	,
		{ib,1,bbinnfw}
	];

	If[ir==irmin&&forecast==1,PrintTemporary["The stochastic simulation will end in ",Round[taux=(SessionTime[]-ttx)(rbins-irmin+1-ncores)/ncores,.1]," s, i.e., on ",DateString[DatePlus[{taux ,"Second"}]]],Null];

	{kapSIM,{1,1}}
,
	{ir,irmin,rbins}
];

,Null];


If[confinement==1&&extrax==0,

simTab=
vTable[
	If[ir==irmin,ttx=SessionTime[],Null];

	kapSIM=ConstantArray[0,nst];
	qfrS=ConstantArray[0,{NobjS,nsts}];
	qfrC=ConstantArray[0,{NobjC,nsts}];

	Do[(* spherical objs *)
		kimSIM=RandomVariate[PoissonDistribution[NOz selS[[ir,io,ib]] denS[[ir,io,ib]]],nsts];
		qfrS[[io]]+= kimSIM/NOz DereffS[[ir,io,ib]]/der;

		kimSIM=Flatten[Table[ConstantArray[kimSIM[[j]],nsts],{j,1,nsts}]]; (* to match the right length *)
		kapSIM+=kappa1S[[ir,io,ib]] (kimSIM/NOz-denS[[ir,io,ib]]);
	,
		{io,1,NobjS}
	,
		{ib,1,bbinsS[objsS[[io,7]]]}
	];

	Do[(* cylindrical objs *)
		kimSIM=RandomVariate[PoissonDistribution[NOz selC[[ir,io,ib]] denC[[ir,io,ib]]],nsts];
		qfrC[[Ceiling[io/tbinsE]]]+= kimSIM/NOz DereffC[[ir,io,ib]]/der;(* iov labels the families of cylinders, io labels the families of \[Theta]-cylinders *)

		kimSIM=Flatten[Table[ConstantArray[kimSIM[[j]],nsts],{j,1,nsts}]]; (* to match the right length *)
		kapSIM+=kappa1C[[ir,io,ib]] (kimSIM/NOz-denC[[ir,io,ib]]);
	,
		{io,1,NobjCE}
	,
		{ib,1,If[theta[Mod[io,tbinsE,1]]==0,bbinsC1[objsC[[Ceiling[io/tbinsE],7]]],bbinsC2[objsC[[Ceiling[io/tbinsE],7]]]]}
	];

	qfr=Total[qfrS,{1}]+Total[qfrC,{1}]; (* total comoving random volume fractions *)
	Xf=qfr/qfa[[ir]];

	Do[(* unconfined halos *)
		kimSIM=RandomVariate[PoissonDistribution[NOz selH[[ir,in,ib]] denH[[ir,in,ib]]],nst];
		kapSIM+=kappa1H[[ir,in,ib]] (kimSIM/NOz-denH[[ir,in,ib]]);
	,
		{in,1,inCONFmin-1}
	,
		{ib,1,bbinnfw}
	];

	Do[(* confined halos *)
		kimSIM=Flatten[MapThread[RandomVariate[PoissonDistribution[#],nsts]&,{Xf NOz selH[[ir,in,ib]] denH[[ir,in,ib]]+10^-15}]];
		kapSIM+=kappa1H[[ir,in,ib]] (kimSIM/NOz-denH[[ir,in,ib]]);
	,
		{in,inCONFmin,nbins}
	,
		{ib,1,bbinnfw}
	];


	If[ir==irmin&&forecast==1,PrintTemporary["The stochastic simulation will end in ",Round[taux=(SessionTime[]-ttx)(rbins-irmin+1-ncores)/ncores,.1]," s, i.e., on ",DateString[DatePlus[{taux ,"Second"}]]],Null];

	{kapSIM,Xf}
,
	{ir,irmin,rbins}
];

,Null];


If[confinement==1&&extrax==1,

simTab=
vTable[
	If[ir==irmin,ttx=SessionTime[],Null];

	kapSIM=ConstantArray[0,nst];
	qfrS=ConstantArray[0,{NobjS,nst}];
	qfrC=ConstantArray[0,{NobjC,nst}];

	Do[(* spherical objs *)
		kimSIM=RandomVariate[PoissonDistribution[NOz selS[[ir,io,ib]] denS[[ir,io,ib]]],nst];
		qfrS[[io]]+= kimSIM/NOz DereffS[[ir,io,ib]]/der;

		kapSIM+=kappa1S[[ir,io,ib]] (kimSIM/NOz-denS[[ir,io,ib]]);
	,
		{io,1,NobjS}
	,
		{ib,1,bbinsS[objsS[[io,7]]]}
	];

	Do[(* cylindrical objs *)
		kimSIM=RandomVariate[PoissonDistribution[NOz selC[[ir,io,ib]] denC[[ir,io,ib]]],nst];
		qfrC[[Ceiling[io/tbinsE]]]+= kimSIM/NOz DereffC[[ir,io,ib]]/der;(* iov labels the families of cylinders, io labels the families of \[Theta]-cylinders *)

		kapSIM+=kappa1C[[ir,io,ib]] (kimSIM/NOz-denC[[ir,io,ib]]);
	,
		{io,1,NobjCE}
	,
		{ib,1,If[theta[Mod[io,tbinsE,1]]==0,bbinsC1[objsC[[Ceiling[io/tbinsE],7]]],bbinsC2[objsC[[Ceiling[io/tbinsE],7]]]]}
	];

	qfr=Total[qfrS,{1}]+Total[qfrC,{1}]; (* total comoving random volume fractions *)
	Xf=qfr/qfa[[ir]];

	Do[(* unconfined halos *)
		kimSIM=RandomVariate[PoissonDistribution[NOz selH[[ir,in,ib]] denH[[ir,in,ib]]],nst];
		kapSIM+=kappa1H[[ir,in,ib]] (kimSIM/NOz-denH[[ir,in,ib]]);
	,
		{in,1,inCONFmin-1}
	,
		{ib,1,bbinnfw}
	];

	Do[(* confined halos *)
		kimSIM=MapThread[RandomVariate[PoissonDistribution[#]]&,{Xf NOz selH[[ir,in,ib]] denH[[ir,in,ib]]+10^-15}];
		kapSIM+=kappa1H[[ir,in,ib]] (kimSIM/NOz-denH[[ir,in,ib]]);
	,
		{in,inCONFmin,nbins}
	,
		{ib,1,bbinnfw}
	];

	If[ir==irmin&&forecast==1,PrintTemporary["The stochastic simulation will end in ",Round[taux=(SessionTime[]-ttx)(rbins-irmin+1-ncores)/ncores,.1]," s, i.e., on ",DateString[DatePlus[{taux ,"Second"}]]],Null];

	{kapSIM,Xf}
,
	{ir,irmin,rbins}
];

,Null];

Clear[kimSIM];


kappazSIM=simTab[[All,1]];
kappaSIM=Total[kappazSIM,{1}];

Xfz=simTab[[All,2]];
XfT= Total[Ggb Xfz] der rhoMC/(-kauE[rs]);


dtt=SessionTime[]-tt;
If[forecast==1,Print[Row[{"Time used for the stochastic simulation=",Round[dtt,.01],"s"}]],Null];


If[
	nhits==1
,
	counts=Round[Total[kimSIMcount,3]/nst,.01];
	ncounts=Total[Total[kimSIMcount,{3}],{1}]/nst;
	zcounts=Total[kimSIMcount,{2,3}]/nst;
	zncounts=Total[kimSIMcount,{3}]/nst;
	zncountsCO=zncounts;Do[zncountsCO[[ir,in]]={zsl[[ir]],ntabc[[in]],zncounts[[ir,in]]},{ir,irmin,rbins},{in,1,nbins}];
	
	Print[Row[{"Average number of hits per light ray: ",counts}]];
	Print[""];
	ncp1=ListPlot[Partition[Riffle[zsl,zcounts],2],Frame->True,FrameStyle->18,Axes->False,FrameLabel->{"z",None,"number of hits per redshift bin"},PlotStyle->Directive[Emerald,PointSize[Large]]];
	ncp2=ListPlot[Partition[Riffle[ntabc,Total[zncounts]],2],Frame->True,FrameStyle->18,Axes->False,FrameLabel->{"\!\(\*SuperscriptBox[\(10\), \(n\)]\)\!\(\*SuperscriptBox[\(h\), \(-1\)]\)\!\(\*SubscriptBox[\(M\), \(\[CircleDot]\)]\)",None,"number of hits per mass bin"},PlotStyle->Directive[Emerald,PointSize[Large]]];
	ncp3=ListPlot[zncountsCO[[{1,12},All,{2,3}]],Frame->True,FrameStyle->18,Axes->False,FrameLabel->{"\!\(\*SuperscriptBox[\(10\), \(n\)]\)\!\(\*SuperscriptBox[\(h\), \(-1\)]\)\!\(\*SubscriptBox[\(M\), \(\[CircleDot]\)]\)",None,Row[{"For the z: {Red,Blue}=",Round[zsl[[{1,12}]],.01]}]},PlotStyle->{Directive[Red,PointSize[Large]],Directive[Blue,PointSize[Large]]}];
	ncpt=GraphicsRow[{ncp1,ncp2,ncp3},Spacings->Scaled[-.2],ImageSize->1000];
	Print@ncpt;

,Null];


(* This code is released under the GPL license. Copyright 2009-2014 by Valerio Marra (valerio.marra@me.com) *)
