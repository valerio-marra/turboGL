(* ::Package:: *)

tpaux=Flatten[Table[{{ntab[[in]],10^4 kappaVarH[[in]]},{ntab[[in+1]],10^4 kappaVarH[[in]]}},{in,1,nbins}],1];
psb1=ListPlot[tpaux,Frame->True,Joined->True,PlotStyle->{Red,Thick},InterpolationOrder->0,
FrameLabel->{"n","variance of convergence - \!\(\*SuperscriptBox[\(10\), \(4\)]\)\!\(\*SubsuperscriptBox[\(\[Sigma]\), \(\[Kappa]\), \(2\)]\)","Halo bins (red), spherical (green) and cylindrical (blue) objs"},FrameStyle->fst];
psb2=If[NobjS==0,Frame->True,ListPlot[Table[{objsS[[io,2]],10^3 kappaVarS[[io]]},{io,1,NobjS}],PlotStyle->Directive[Green,PointSize[Large]]]];
If[
	NobjC==0
,
	pab=Show[psb1,psb2,PlotRange->All]
,
	psb3=ListPlot[Table[{objsC[[io,2]],10^3 kappaVarC[[io]]},{io,1,NobjC}],PlotStyle->Directive[Blue,PointSize[Large]]];
	pab=Show[psb1,psb3,psb2,PlotRange->All];
];

z1=0;ksx=ksiz[z1];
Which[
	adi==1
,
	pkplot=LogLogPlot[{(a0 hh)^3 PkHMFast[k hh,z1],(a0 hh)^3 PkL[k hh,z1],(a0 hh)^3 PkHzFast[k hh,z1],(a0 hh)^3 PkHaloFit[k hh,z1,ksx]},{k,.03 a0,2 a0},Frame->True,FrameStyle->fst,PlotPoints->6,MaxRecursion->2,
PlotStyle->{{Thick,Orange},{Green, Dashed, Thick},{Blue, DotDashed, Thick},Black},FrameLabel->{"k [h/Mpc]","P(k)","Halo model (orange) and HaloFit (black) at z=0"}];
,
	adi==2
,
	pkplot=LogLogPlot[{DEL2HMFast[k hh,z1], DEL2k[k hh,z1], DEL2HzFast[k hh,z1], DEL2HaloFit[k hh,z1,ksx]},{k,.03 a0,2 a0},Frame->True,FrameStyle->fst,PlotPoints->6,MaxRecursion->2,
PlotStyle->{{Thick,Orange},{Green, Dashed, Thick},{Blue, DotDashed, Thick},Black},FrameLabel->{"k [h/Mpc]","\!\(\*SuperscriptBox[\(\[CapitalDelta]\), \(2\)]\)(k)","Halo model (orange) and HaloFit (black) at z=0"}];
,
	adi==0
,
	pkplot=Style["\[FreakedSmiley]",FontSize->200];
];

pplots=GraphicsRow[{pab,pkplot},Spacings->Scaled[-0.05],ImageSize->920];


cole1={"<\[Kappa]>","\[Sigma]","\!\(\*SubscriptBox[\(\[Kappa]\), \(E\)]\)","\!\(\*SubscriptBox[\(\[Kappa]\), \(UE\)]\)"};
cole2={Round[kappaMean,10^-3.],nneat[kappaSigma],Round[kappaE,10^-3.],Round[kappaUE,10^-3.]};
coleA=TableForm[cole2,TableHeadings->{cole1,None},TableAlignments->Center];

If[
	adi==0
,
	coleB="";
,
	cole1={"\[Sigma][tGL + linear Pk]","\[Sigma][linear Pk - \!\(\*SubscriptBox[\(k\), \(max\)]\)=\[Infinity]]","\[Sigma][HaloFit Pk - \!\(\*SubscriptBox[\(k\), \(max\)]\)=10h/Mpc]"};
	cole2={nneat[(kappaVarHPb+kappaVarL[rs])^.5],nneat[kappaSigmaLT[rs]],If[ksiz[zod]<0,"HaloFit failed",nneat[kappaSigmaNLTX[rs,2\[Pi]/(10 hh)]]]};
	coleB=TableForm[cole2,TableHeadings->{cole1,None},TableAlignments->Center];
];


hsc={
Sum[1,{ir,irmin,rbins},{in,1,nbins},{ib,1,bbinnfw}]
,
Sum[1,{ir,irmin,rbins},{io,1,NobjS},{ib,1,bbinsS[objsS[[io,7]]]}]
,
Sum[1,{ir,irmin,rbins},{io,1,NobjCE},{ib,1,If[theta[Mod[io,tbinsE,1]]==0,bbinsC1[objsC[[Ceiling[io/tbinsE],7]]],bbinsC2[objsC[[Ceiling[io/tbinsE],7]]]]}]
};

Print[Column[{
Row[{coleA,"      ",coleB,"   -   # of bins: {halos, sph, cyl}=",hsc,"   -   time used=",Round[dtt+dtt2,.01],"s"}],
"",
pplots
}]];


(* This code is released under the GPL license. Copyright 2009-2014 by Valerio Marra (valerio.marra@me.com) *)
