(* ::Package:: *)

tt=SessionTime[];


(* unprocessed mean and sigma *)

tmeank[jz]=Mean[kappaSIM];
sigmak[jz]=StandardDeviation[kappaSIM];


(* kappaSIMcx is only affected by koncut *)

scartix=Position[kappaSIM,x_/;x>koncut];
kappaSIMcx=Delete[kappaSIM,scartix];


(* histogram binning *)

muex=Min[kappaSIM] 1.0001;
nbinhi[nsta_]:=6 Log[10,nsta]-13.;(* to set the histogram bins *)
nmu=Round[nbinhi[nst]];nmu=15; (*  11 for cosmo high-z tables - 15 for the other tables - to override the bin number *)
dmu=-muex/nmu;
nmue=20; (* 12 for cosmo high-z tables - 20 for the other tables - length of the tail *)
imax=(nmue+1) nmu; (* 143 for cosmo high-z tables - 315 for the other tables  *)

koncuteff=Min[muex+dmu imax,koncut];
scarti=Position[kappaSIM,x_/;x>koncuteff];(* convergences in the high magnification tail that are neglected - harmless if the weak-lensing approximation holds *)
persca=N[Length[scarti]/nst];
If[persca>10^-2,Print[Row[{"Purged fraction= ",nneat[persca],
"  -  {h,Om,Ok,Oq,w0,Ob,s8,ns,\[Gamma],z,nstat,kcut}=",Round[{hh,OmegaM0,OmegaK0,OmegaQ0,w0,OmegaB0,sig8,nsp,gammaGro,zod,Log10[nst],koncut},.001]}]]];
kappaSIMc=Delete[kappaSIM,scarti];

bintap=Sort[Table[muex+dmu (i+1/2),{i,0,imax-1}]];
bindiv=Sort[Table[muex+dmu i,{i,0,imax}]];
bincou=BinCounts[kappaSIMc,{bindiv}]/(dmu nst);
tapx=Table[{bintap[[i]],bincou[[i]]},{i,1,imax}];
normu=Total[tapx[[All,2]]]dmu;
tapx[[All,2]]=tapx[[All,2]]/normu;


(*(* correction to ensure the right mean and normalization *)

meanu=Total[tapx[[All,2]]tapx[[All,1]]]dmu
dpc=(tmeank[jz]-meanu) /(dmu Total[tapx[[All,1]]]-dmu tmeank[jz] imax);
tapx[[All,2]]=(tapx[[All,2]]+dpc)/(1+dpc imax dmu);*)


(* PDF for desired observable (turboGL computes convergences) *)

Which[
	PDFtype==1
,
	lbl="\[Kappa]";
	EmptyB[z_]:=kauE[rz[z]];PFillB[z_]:=kauUE[rz[z]];
,
	PDFtype==2
,
	lbl="\[CapitalDelta]m";
	Which[
		nlinear==1,tapx[[All,1]]=5 Log[10,1-tapx[[All,1]]];EmptyB[z_]:=5 Log[10,1-kauE[rz[z]]];PFillB[z_]:=5 Log[10,1-kauUE[rz[z]]];
		kappaSIMc=5 Log[10,1-kappaSIMc];
	,
		nlinear==0,tapx[[All,1]]=(-5./Log[10])tapx[[All,1]];EmptyB[z_]:=(-5./Log[10])kauE[rz[z]];PFillB[z_]:=(-5./Log[10])kauUE[rz[z]];
		kappaSIMc=(-5./Log[10])kappaSIMc;
	];
,
	PDFtype==3 (* the mean magnification of 1 is subtracted *)
,
	lbl="\[Mu]-1";
	Which[
		nlinear==1,tapx[[All,1]]=(1-tapx[[All,1]])^-2 -1;EmptyB[z_]:=(1-kauE[rz[z]])^-2 -1;PFillB[z_]:=(1-kauUE[rz[z]])^-2 -1;
		kappaSIMc=(1-kappaSIMc)^-2 -1;
	,
		nlinear==0,tapx[[All,1]]=1+2 tapx[[All,1]] -1;EmptyB[z_]:=1+2 kauE[rz[z]] -1;PFillB[z_]:=1+2 kauUE[rz[z]] -1;
		kappaSIMc=1+2 kappaSIMc -1;
	];
];

(*diffi=Abs[Differences[tapx[[All,1]]]];
diffi=AppendTo[diffi,Last[diffi]];*)
nonconstantB[Abs[Differences[tapx[[All,1]]]]];
diffi=dbinsB;

normu=Total[diffi tapx[[All,2]]];
tapx[[All,2]]=tapx[[All,2]]/normu; (* tapx is the final histogram *)


dtt2=SessionTime[]-tt;
gtt4x=dtt+dtt2;


(* This code is released under the GPL license. Copyright 2009-2014 by Valerio Marra (valerio.marra@me.com) *)
