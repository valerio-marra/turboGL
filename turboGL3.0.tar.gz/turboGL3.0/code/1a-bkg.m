(* ::Package:: *)

tt=SessionTime[];


(* cosmological quantities *)

OmegaG0=2.469 10^-5/hh^2; (* photon density parameter *)
Neff=3.046; (* massless neutrinos *)
OmegaR0= OmegaG0 (1+0.2271 Neff); (* radiation density parameter *)

OmegaQ0=1-OmegaM0-OmegaK0-OmegaR0; (* dark-energy density parameter *)

rhoMC=OmegaM0 rhoc0 a0^3; (* (constant) matter density in a comoving volume *)

kk=-OmegaK0 a0^2 /Lh0^2; (* curvature constant *)
Lk0=If[Sqrt[Abs[OmegaK0]]>10^-2,Lh0/Sqrt[Abs[OmegaK0]],Infinity]; (* =a0/Sqrt[kk] spatial curvature radius *)


(* dark-energy equation of state: if, e.g., a quintessence field is used one has to solve the evolution before and plug here the resulting w(z) *)

wa=0;
ww[z_]=w0+wa z/(1+z);

(*wave[z_]:=Simplify[Integrate[ww[z1]/(1+z1),{z1,0,z},Assumptions->z>0]/Log[1+z]];*)
epsos=10.^-8; (* to have it numerically well behaved at z=0 *)
wave[z_]=w0+wa -wa (z+epsos)/((1+z+epsos)Log[1+z+epsos]);


(* Friedmann equation *)

Ez[z_]:=Sqrt[OmegaQ0 (1+z)^(3 (1+wave[z])) + OmegaK0 (1+z)^2 + OmegaM0 (1+z)^3 + OmegaR0 (1+z)^4];
Hz[z_]:=H0 Ez[z];
rhoz[z_]:=(3 Hz[z]^2)/(8 \[Pi] GG);

rhoQz[z_]:=(3 H0^2)/(8 \[Pi] GG)OmegaQ0 (1+z)^(3 (1+wave[z]));
rhoKz[z_]:=(3 H0^2)/(8 \[Pi] GG)OmegaK0 (1+z)^2;
rhoMz[z_]:=(3 H0^2)/(8 \[Pi] GG)OmegaM0 (1+z)^3;
rhoRz[z_]:=(3 H0^2)/(8 \[Pi] GG)OmegaR0 (1+z)^4;

OmegaQz[z_]:= OmegaQ0/Ez[z]^2 (1+z)^(3 (1+wave[z]));
OmegaKz[z_]:= OmegaK0/Ez[z]^2 (1+z)^2;
OmegaMz[z_]:= OmegaM0/Ez[z]^2 (1+z)^3;
OmegaRz[z_]:= OmegaR0/Ez[z]^2 (1+z)^4;

t0=Re[NIntegrate[1/(a Hz[a0/a-1]),{a,0,a0},Method->{Automatic,"SymbolicProcessing"->0}]];
tmin=t0 1/1000; (* 1/300 - minimum time, to be changed if needed *)

(* wrt time *)
(*at[t_]=First[Evaluate[afi[t]/.NDSolve[{afi'[t]==afi[t] Hz[a0/afi[t]-1],afi[t0]==a0},afi,{t,tmin,t0},MaxStepFraction->1/ACCU]]];*)

(* wrt log t: t -> x=Log[t/tx] -  dx=dt/t and dt=tx Exp[x] dx *)
tx=tmin/5;tminx=Log[tmin/tx];t0x=Log[t0/tx];
atx[x_]=First[Evaluate[afi[x]/.NDSolve[{(tx Exp[x])^-1 afi'[x]==afi[x] Hz[a0/afi[x]-1],afi[t0x]==a0},afi,{x,tminx,t0x},MaxStepFraction->1/ACCU]]];
at[t_]=atx[Log[t/tx]];ClearAll[atx,tx,tminx,t0x];

RR[t_]:=6/cc^2 (at''[t]/at[t]+at'[t]^2/at[t]^2+kk cc^2/at[t]^2); (* Ricci *)
zt[t_]:=a0/at[t]-1;
zfar=zt[tmin];

za[a_]:=a0/a-1;
az[z_]:=a0/(1+z);


(* distances *)

r1m=1; (* physical distance of 1 Mpc *)
dLfid[z_]:=Lh0 (z^2+ 2 z)/2;
mofid[z_]:=5 Log[10,dLfid[z]/r1m]+25;
dLEdS[z_]:= 2 Lh0 (1+z-Sqrt[1+z]);
moEdS[z_]:=5 Log[10,dLEdS[z]/r1m]+25;
dmEdS[z_]:=5 Log[10,dLEdS[z]/dLfid[z]];

fk[r_]:=Piecewise[{{r,kk==0},{Sinh[Sqrt[-kk]r]/Sqrt[-kk],kk<0},{Sin[Sqrt[kk]r]/Sqrt[kk],kk>0}}];

(* r(z) *)
(* dC[z_]=First[dCf[z]/.NDSolve[{dCf'[z]==Lh0/a0 1/Ez[z],dCf[0]==0},dCf,{z,0,zfar},MaxStepFraction->1/ACCU]]; *)
(* dC[z_]:=Lh0/a0 NIntegrate[1/Ez[zdu],{zdu,0,z},Method->{Automatic,"SymbolicProcessing"->0}]; *)
zfardi=zfar;
dC[z_]=First[dCf[z]/.NDSolve[{dCf'[z]==Lh0/a0 1/Ez[z],dCf[0]==0},dCf,{z,0,zfardi},MaxStepFraction->1/ACCU]];
rfardi=dC[zfardi];

dCt[z_]:=fk[dC[z]];
dA[z_]:=a0 dCt[z]/(1+z);
dL[z_]:=a0 dCt[z](1+z);
mo[z_]:=5 Log[10,dL[z]/r1m]+25;
dm[z_]:=5 Log[10,dL[z]/dLfid[z]];


(* light cone *)

itf=NDSolve[{cc tf'[r]==-at[tf[r]],tf[0]==t0},tf[r],{r,0,rfardi},MaxStepFraction->1/ACCU];
tr[r_]=First[Evaluate[tf[r]/.itf]];

irf=NDSolve[{rf'[z]==Lh0/a0 1/Ez[z],rf[0]==0},rf[z],{z,0,zfardi},MaxStepFraction->1/ACCU];
rz[z_]=First[Evaluate[rf[z]/.irf]]; (* faster than dC[z] *)

zr[r_]:=zt[tr[r]];
tz[z_]:=tr[rz[z]];


dtt=SessionTime[]-tt;
gtt1=dtt;


(* This code is released under the GPL license. Copyright 2009-2014 by Valerio Marra (valerio.marra@me.com) *)
