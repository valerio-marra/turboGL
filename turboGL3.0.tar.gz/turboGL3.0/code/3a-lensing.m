(* ::Package:: *)

(* lensing optical-weight function G *)

Gg[r_,rs_]:=4\[Pi] GG/cc^2 (fk[r] fk[rs-r]/fk[rs]) 1/at[tr[r]];


(* empty-beam convergence *)

kauE[rs_]:=-rhoMC NIntegrate[Gg[r,rs],{r,0,rs},Method->{Automatic,"SymbolicProcessing"->0}];


(*(* splitting angle *)
split[r_,rs_,b_,M_]:=0;

(* ellipticity *)
ecce[r_,rs_,phi_,b_,M_]:=0;*)


(* lensing variance from linear Pk - with k cut *)

akuxL[z_?NumericQ]:=(*akuxL[z]=*)\[Pi] NIntegrate[DEL2k[a0 k,z]/(a0 k^2) ,{k,0,kcut[z]},Method->{Automatic,"SymbolicProcessing"->0}];
kappaVarL[rs_]:=(*kappaVarL[rs]=*)1/NOz rhoMC^2 NIntegrate[Gg[r,rs]^2 akuxL[zr[r]],{r,0,rs},Method->{Automatic,"SymbolicProcessing"->0}];
kappaSigmaL[rs_]:=Sqrt[kappaVarL[rs]];
(* binned version *)
kappaVarLb:=1/NOz rhoMC^2 der Sum[Ggb[[ir]]^2 akuxL[zsl[[ir]]],{ir,irmin,rbins}];
kappaSigmaLb:=Sqrt[kappaVarLb];

(* lensing variance from halo Pk - with k cut *)

akuxH[z_?NumericQ]:=(*akuxH[z]=*)1/(2\[Pi]) NIntegrate[PkHzFast[a0 k,z] a0^2 k,{k,kcut[z],10 hh},Method->{Automatic,"SymbolicProcessing"->0}];
kappaVarHP[rs_]:=(*kappaVarHP[rs]=*)1/NOz rhoMC^2 NIntegrate[Gg[r,rs]^2 akuxH[zr[r]],{r,0,rs},Method->{Automatic,"SymbolicProcessing"->0}];
kappaSigmaHP[rs_]:=Sqrt[kappaVarHP[rs]];
(* binned version *)
kappaVarHPb:=1/NOz rhoMC^2 der Sum[Ggb[[ir]]^2 akuxH[zsl[[ir]]],{ir,irmin,rbins}];
kappaSigmaHPb:=Sqrt[kappaVarHPb];


(* lensing variance from HaloFit *)

akuxNLTX[z_?NumericQ,\[Lambda]_?NumericQ]:=\[Pi] NIntegrate[DEL2HaloFit[a0 k,z,ksiz[z]]/(a0 k^2) ,{k,0,2\[Pi]/\[Lambda]},Method->{Automatic,"SymbolicProcessing"->0}];
kappaVarNLTX[rs_,\[Lambda]_]:=1/NOz rhoMC^2 NIntegrate[Gg[r,rs]^2 akuxNLTX[zr[r],\[Lambda]],{r,0,rs},Method->{Automatic,"SymbolicProcessing"->0}];
kappaSigmaNLTX[rs_,\[Lambda]_]:=Sqrt[kappaVarNLTX[rs,\[Lambda]]];


(* lensing variance from linear Pk - no k cut *)

akuxLT[z_?NumericQ]:=\[Pi] NIntegrate[DEL2k[a0 k,z]/(a0 k^2) ,{k,0,\[Infinity]},Method->{Automatic,"SymbolicProcessing"->0}];
kappaVarLT[rs_]:=1/NOz rhoMC^2 NIntegrate[Gg[r,rs]^2 akuxLT[zr[r]],{r,0,rs},Method->{Automatic,"SymbolicProcessing"->0}];
kappaSigmaLT[rs_]:=Sqrt[kappaVarLT[rs]];


(* This code is released under the GPL license. Copyright 2009-2014 by Valerio Marra (valerio.marra@me.com) *)
