=========================================================================
Last updated: 11 Dec 2014
http://www.turbogl.org/
Version: 3.0
=========================================================================
CREDITS

The turboGL code is based on the sGL method first introduced in Kainulainen & Marra 2009 (arXiv:0909.0822) and extended/revised in Kainulainen & Marra 2010 (arXiv:1011.0732).
When using turboGL, or part of it, please acknowledge both the turboGL code and the sGL method and cite the papers arXiv:0909.0822 and arXiv:1011.0732.


=========================================================================
INSTRUCTIONS

The following instructions only explain how to use turboGL. See the papers arXiv:0909.0822 and arXiv:1011.0732 for a detailed explanation of the sGL method. To run the code you need at least Mathematica 8; Mathematica 9&10 are fully supported. Do note move the Mathematica files from the relative folders. Start by opening the notebook "master.nb". The analysis consists of a few easy steps.

Section 1. Here you set the cosmological background.

Section 2. You set here the mass spectrum. There are 4 substeps:
a- the first block of code sets the linear power spectrum. Besides self-explaining parameters, you can set a non-standard growth rate. You have three choices: i) exact GR, ii) step-wise parametrization of the growth rate, iii) the usual gamma-parametrization.
b- here you can choose the halo mass function and the halo mass range to be used by turboGL.
c- optional. You can specify here if and how to confine bigger halos inside spherical or cylindrical low-contrast structures, which are specified using obj[]. See legend at the end of the Section for more details.

Section 3. Here the relevant quantities are binned. Optionally, it outputs the power spectrum relative to the halos specified through the parameters given in Section2a-b. After this Section the universe is set.
The parameter "NOz" is the number of observations at the chosen redshift. If NOz=1, then the lensing PDF relative to a single observation is calculated (the fundamental PDF). If NOz is not 1, then the lensing PDF relative to the mean magnitude of a set of NOz observations is calculated.

Section 4. Here the stochastic simulation is run, that is, many realizations of the matter spectrum are created using the quantities computed in Section 3.
Some remarks:
- "jz" lets you label a given run so that new runs do not overwrite old ones.
- the linear conversion between convergence and magnitude/flux (nlinear=0) is the safest choice as it always guaranties the correct mean.
- if sigmaconvo=0, then the analysis is done wrt the lensing PDF. If sigmaconvo is not zero, then the lensing PDF is convolved with a gaussian of dispersion sigmaconvo and the analysis is done wrt the convolved PDF. A nonzero sigmaconvo simulates the effect of the SNe intrinsic dispersion.


Have fun,

Valerio


=========================================================================
ACKNOWLEDGEMENTS

Valerio Marra benefited from many discussions with Kimmo Kainulainen during the development of the turboGL code.


=========================================================================
COPYRIGHT STATUS

Copyright 2009-2014 by Valerio Marra (valerio.marra@me.com)


=========================================================================
LICENSE

For the code that no third party owns patents, copyrights or trademarks for, turboGL is released under the GNU's General Public License, see the attached license.txt file.
